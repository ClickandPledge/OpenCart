<?php 
class ModelPaymentCnP extends Model {
  	public function getMethod($address, $total) {
		$this->load->language('payment/cnp');
		$currency = $this->currency->getId();
		 $taxes = $this->cart->getTaxes();
		 //start
			 $total=0;
			 $handling_data = array();
			 $reward_data = array();
			 $ship_data = array();
			 $tax_data = array();
			 $coupon_data = array();
			 $voucher_data = array();
			 $subtotal_data = array();
			 $total_data = array();
			 $loworderfee_data = array();
			 $taxes = $this->cart->getTaxes();

			 //$results = $this->model_checkout_extension->getExtensions('total');
				if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {						 
				$this->load->model('extension/extension');
				
				$sort_order = array(); 
				
			   $results = $this->model_extension_extension->getExtensions('total');	
				
				foreach ($results as $key => $value) {
					 $sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
				}
				
				array_multisort($sort_order, SORT_ASC, $results);
			}

			 foreach ($results as $result) {
					if ($this->config->get($result['code'] . '_status')) {
						if($result['code'] == "handling")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($handling_data, $total, $taxes);
						}
						if($result['code'] == "low_order_fee")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($loworderfee_data, $total, $taxes);
						}
						 
						if($result['code'] == "reward")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($reward_data, $total, $taxes);
						}
					 
						if($result['code'] == "shipping")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($ship_data, $total, $taxes);
						}
						if($result['code'] == "tax")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($tax_data, $total, $taxes);
						}
						if($result['code'] == "coupon")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($coupon_data, $total, $taxes);
						}
						if($result['code'] == "voucher")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($voucher_data, $total, $taxes);
						}
						if($result['code'] == "sub_total")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($subtotal_data, $total, $taxes);
						}
						if($result['code'] == "total")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($total_data, $total, $taxes);
						}
					
					
					}			 
				 
		     }	
			// echo "<pre>";
			 //print_r($this->currency->getCode());
					$pound = $this->currency->getSymbolLeft();
					$dollor = $this->currency->getSymbolRight();
					$exp=array($pound,$dollor,",","-");
					 if(isset($total_data) && !empty($total_data))
					{
						foreach($total_data as $total_disp)
						{
						  $total_disp_value = str_replace($exp,"",$total_disp['value']);
						}
						}else{
						$total_disp_value = 000;
					}
		 
		 // end
		if ($this->config->get('cnp_usd_status')==1 && $this->currency->getCode() == 'USD') {
		   
      		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('cod_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		if ($this->config->get('cnp_checkout_total') > 0 && $this->config->get('cnp_checkout_total') > $total_disp_value) {
		 $status = FALSE;
			}elseif (!$this->config->get('cod_geo_zone_id')) {
        		$status = TRUE;
      		} elseif ($query->num_rows) {
      		  	$status = TRUE;
      		} else {
     	  		$status = FALSE;
			}	
      	} elseif($this->config->get('cnp_status_euro')==1 && $this->currency->getCode() == 'EUR') {
        		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('cod_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		if ($this->config->get('cnp_checkout_total') > 0 && $this->config->get('cnp_checkout_total') > $total_disp_value) {
		 $status = FALSE;
		 } elseif (!$this->config->get('cod_geo_zone_id')) {
        		$status = TRUE;
      		} elseif ($query->num_rows) {
      		  	$status = TRUE;
      		} else {
     	  		$status = FALSE;
			}	
      		
		} elseif($this->config->get('cnp_status_pound')==1 && $this->currency->getCode() == 'GBP'){
		     
		 $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('cod_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		
		if ($this->config->get('cnp_checkout_total') > 0 && $this->config->get('cnp_checkout_total') > $total_disp_value) {
			 $status = FALSE;
		 }elseif (!$this->config->get('cod_geo_zone_id')) {
        		$status = TRUE;
      		} elseif ($query->num_rows) {
      		  	$status = TRUE;
      		} else {
     	  		$status = FALSE;
			}	
		} elseif($this->config->get('cnp_cad_status')==1 && $this->currency->getCode() == 'CAD'){
		     
		 $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('cod_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		
		if ($this->config->get('cnp_checkout_total') > 0 && $this->config->get('cnp_checkout_total') > $total_disp_value) {
			 $status = FALSE;
		 }elseif (!$this->config->get('cod_geo_zone_id')) {
        		$status = TRUE;
      		} elseif ($query->num_rows) {
      		  	$status = TRUE;
      		} else {
     	  		$status = FALSE;
			}	
		} elseif($this->config->get('cnp_hkd_status')==1 && $this->currency->getCode() == 'HKD'){
		     
		 $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('cod_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		
		if ($this->config->get('cnp_checkout_total') > 0 && $this->config->get('cnp_checkout_total') > $total_disp_value) {
			 $status = FALSE;
		 }elseif (!$this->config->get('cod_geo_zone_id')) {
        		$status = TRUE;
      		} elseif ($query->num_rows) {
      		  	$status = TRUE;
      		} else {
     	  		$status = FALSE;
			}	
		} else {
			$status = FALSE;
		}
		
		$method_data = array();

		if ($status) {  
      		$method_data = array( 
        		'code'         => 'cnp',
        		'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('cnp_sort_order')
      		);
    	}
   		//$recurring_products = $this->cart->getRecurringProducts();
		
		//echo '<pre>';
		//print_r($recurring_products);
    	return $method_data;
  	}
	
	/*	public function recurringPayments() {
		
		 * Used by the checkout to state the module
		 * supports recurring recurrings.
		 
		return true;
	}*/

	
}
?>