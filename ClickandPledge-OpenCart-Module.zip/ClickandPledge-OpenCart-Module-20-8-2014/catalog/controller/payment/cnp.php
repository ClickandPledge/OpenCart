<?php
class ControllerPaymentCnP extends Controller{

     protected function index() {
		$this->language->load('payment/cnp');
        
		$this->data['text_credit_card'] = $this->language->get('text_credit_card');
		$this->data['text_wait'] = $this->language->get('text_wait');
		
		$this->data['entry_cc_owner'] = $this->language->get('entry_cc_owner');
		$this->data['entry_cc_number'] = $this->language->get('entry_cc_number');
		$this->data['entry_cc_expire_date'] = $this->language->get('entry_cc_expire_date');
		$this->data['entry_cc_cvv2'] = $this->language->get('entry_cc_cvv2');

		$this->data['button_confirm'] = $this->language->get('button_confirm');
		$this->data['button_back'] = $this->language->get('button_back');
        


		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/cnp.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/payment/cnp.tpl';
		} else {
			$this->template = 'default/template/payment/cnp.tpl';
		}

		$this->render();

     }
	 
	public function floor_dec($number,$precision,$separator)
	{
	if(strstr($number,'.'))
	{
	$numberpart=@explode($separator,$number);
	$ceil_number= array($numberpart[0],substr($numberpart[1],0,2));
	return implode($separator,$ceil_number);
	}
	return $number;
	}
	 
	 public function Creditcard()
	 {
	
	$add = '';
	if(isset($_POST['recurring']) && $_POST['recurring'] == 'on')
	{ ?>
	<script type="text/javascript">var recurring_units= new Array(); recurring_units = ["<?php  echo $_POST['recurring_units_week']; ?>","<?php  echo $_POST['recurring_units_week2']; ?>","<?php  echo $_POST['recurring_units_month']; ?>","<?php  echo $_POST['recurring_units_month2']; ?>","<?php  echo $_POST['recurring_units_quarter']; ?>","<?php  echo $_POST['recurring_units_month6']; ?>","<?php  echo $_POST['recurring_units_year']; ?>"]; var indefinite = "<?php echo $_POST['indefinite'];?>"</script>
	<?php
	$add = '<div id="myElementId"><h3>Payment Options</h3><div style="margin-bottom:10px; margin-top:10px;"><input type="radio" id="is_recurring" name="is_recurring" value="0" checked="checked" onclick="recurring_setup(this.value);"><label class="option" for="is_recurring"><span></span> I want to make a one-time payment</div><div style="margin-bottom:10px;"><input type="radio" id="recurring-manytime" name="is_recurring" value="1" onclick="recurring_setup(this.value,\''.$_POST['recurring_installment'].'\',\''.$_POST['recurring_subscription'].'\',recurring_units,indefinite);"><label class="option" for="recurring-manytime"><span></span> I want to make a recurring payment</label>
	</div><div id="method_display" style="padding-left:20px;"></div>';
	$add .= '</div>';
	}
	 
	$currentYear = date("Y");
	$currentMonth = date("m");
	 $html = $add;
     $html  .= "<table class='form' style='margin-top:10px'><tr><td>Name on Card <span class='required'>*</span></td><td><input type='text' name='cc_owner' value='' id='cc_owner'/></td></tr>";
	 $html .="<tr><td>Credit Card Number <span class='required'>*</span></td><td><input type='text' name='cc_number' value='' id='cc_number' maxlength='16'/></td></tr>";
	 $html .="<tr><td>Expiration Date <span class='required'>*</span></td><td><select name='cc_expire_date_month' id='cc_expire_date_month'>";
		for ($i = 1; $i <= 12; $i++) {
			$months[] = array('text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
				              'value' => sprintf('%02d', $i));
		    }
		$today = getdate();

		for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
			$year_expire[] = array('text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
				                 'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)));
		}
	 foreach ($months as $month) { 
     if($currentMonth == $month['value']){
	 $html .="<option value='".$month['value']."' selected>".$month['text']."</option>";
	 }else{
     $html .="<option value=".$month['value'].">".$month['text']."</option>";  
		  }
		  }
	 $html .= "</select> / <select name='cc_expire_date_year' id='cc_expire_date_year'>";
	 foreach ($year_expire as $year) {
	  if($currentYear ==$year['value']){
	  $html .= "<option value='".$year['value']."' selected>".$year['text']."</option>"; 
	  }else{
	  $html .="<option value='".$year['value']."'>".$year['text']."</option>";
	  }}
	  $html .= "</select></td></tr><tr><td>Card Verification (CVV) <span class='required'>*</span></td><td><input type='text' name='cc_cvv2' id='cc_cvv2' value='' size='4' maxlength='4'/></td></tr> </table>"; 
	  $html .="<div class='buttons'><div class='right'><input type='button' value='Confirm Order' id='button-confirm' class='button' onclick='return credit_card_valid();' /></div></div>";
	  echo $html;
     }
	 
	 public function eCheck()
	 {
		 
		$add = '';
		if(isset($_POST['recurring']) && $_POST['recurring'] == 'on')
		{ ?>
		<script type="text/javascript">var recurring_units= new Array(); recurring_units = ["<?php  echo $_POST['recurring_units_week']; ?>","<?php  echo $_POST['recurring_units_week2']; ?>","<?php  echo $_POST['recurring_units_month']; ?>","<?php  echo $_POST['recurring_units_month2']; ?>","<?php  echo $_POST['recurring_units_quarter']; ?>","<?php  echo $_POST['recurring_units_month6']; ?>","<?php  echo $_POST['recurring_units_year']; ?>"]; var indefinite = "<?php echo $_POST['indefinite'];?>"</script>
		<?php
		$add = '<div id="myElementId"><h3>Payment Options</h3><div style="margin-bottom:10px; margin-top:10px;"><input type="radio" id="is_recurring" name="is_recurring" value="0" checked="checked" onclick="recurring_setup(this.value);"><label class="option" for="is_recurring"><span></span> I want to make a one-time payment</div><div style="margin-bottom:10px;"><input type="radio" id="recurring-manytime" name="is_recurring" value="1" onclick="recurring_setup(this.value,\''.$_POST['recurring_installment'].'\',\''.$_POST['recurring_subscription'].'\',recurring_units,indefinite);"><label class="option" for="recurring-manytime"><span></span> I want to make a recurring payment</label>
		</div><div id="method_display" style="padding-left:20px;"></div>';
		$add .= '</div>';
		}
	 $html = $add;
     $html  .= "<table class='form' style='margin-top:10px'><tr><td>Routing Number <span class='required'>*</span></td><td><input type='text' name='RoutingNumber' id='RoutingNumber' size='20' maxlength='9' autocomplete='Off'/></td></tr>";
	 $html .="<tr><td>Check Number <span class='required'>*</span></td><td><input type='text' name='CheckNumber' id='CheckNumber' size='20' maxlength='10' autocomplete='Off'/></td></tr>";
	 $html .="<tr><td>Account Number <span class='required'>*</span></td><td><input type='text' name='AccountNumber' id='AccountNumber' size='20' maxlength='17' autocomplete='Off'/></td></tr>";
     $html  .= "<tr><td>Retype Account Number <span class='required'>*</span></td><td><input type='text' name='RetypeAccountNumber' id='RetypeAccountNumber' size='20' maxlength='17' autocomplete='Off'/></td></tr>";
	 $html .="<tr><td>Account Type </td><td><select name='AccountType' id='AccountType'><option value='SavingsAccount'>Savings Account</option><option value='CheckingAccount'>Checking Account</option></select></td></tr>";
	 $html .="<tr><td>Check Type </td><td><select name='CheckType' id='CheckType'><option value='Company'>Company</option><option value='Personal'>Personal</option></select></td></tr>";
     $html  .= "<tr><td>Name on Account <span class='required'>*</span></td><td><input type='text' name='NameOnAccount' id='NameOnAccount' size='20' maxlength='100' autocomplete='Off'/></td></tr></table>";
	  $html .="<div class='buttons'><div class='right'><input type='button' value='Confirm Order' id='button-confirm' class='button' onclick='return echeck_valid();'/></div></div>";
	  echo $html;
	 
     }

	 public function Invoice()
	 {
     $html  = "<table class='form' style='margin-top:10px'><tr><td>Check Number </td><td><input type='text' name='InvoiceCheckNumber' id='InvoiceCheckNumber' size='20' maxlength='50' autocomplete='Off'/></td></tr></table>";
	  $html .="<div class='buttons'><div class='right'><input type='button' value='Confirm Order' id='button-confirm' class='button' onclick='return invoice_valid();'/></div></div>";
	  echo $html;
     }
	 
	 public function PurchaseOrder()
	 {
     $html  = "<table class='form' style='margin-top:10px'><tr><td>Purchase Order Number </td><td><input type='text' name='PurchaseOrderNumber' id='PurchaseOrderNumber' size='20' maxlength='50' autocomplete='Off'/></td></tr></table>";
	  $html .="<div class='buttons'><div class='right'><input type='button' value='Confirm Order' id='button-confirm' class='button' onclick='return purchaseorder_valid();'/></div></div>";
	 
	  echo $html;
	 }
	 
	 public function send() {
	 
	         $this->load->model('checkout/order');
			 $this->load->model('checkout/coupon');
			 $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
//print_r($order_info);exit;
			 /***********  opencart Country codes ***************/
			 
			$opencart_country_code = array('1'=>'004','2'=>'008','3'=>'012','4'=>'016','5'=>'020','6'=>'024','7'=>'660','8'=>'010','9'=>'028','10'=>'032',
			'11'=>'051','12'=>'533','13'=>'036','14'=>'040','15'=>'031','16'=>'044','17'=>'048','18'=>'050','18'=>'050','19'=>'052','20'=>'112','21'=>'056','22'=>'084',
			'23'=>'204','24'=>'060','25'=>'064','26'=>'068','27'=>'070','28'=>'072','29'=>'074','30'=>'076','31'=>'086','32'=>'096','33'=>'100','34'=>'854','35'=>'108',
			'36'=>'116','37'=>'120','38'=>'124','39'=>'132','40'=>'136','41'=>'140','42'=>'148','43'=>'152','44'=>'156','45'=>'162','46'=>'166','47'=>'170','48'=>'174',
			'49'=>'178','50'=>'184','51'=>'188','52'=>'384','53'=>'191','54'=>'192','55'=>'196','56'=>'203','57'=>'208','58'=>'262','59'=>'212','60'=>'214','61'=>'626',
			'62'=>'218','63'=>'818','64'=>'222','65'=>'226','66'=>'232','67'=>'233','68'=>'231','69'=>'238','70'=>'234','71'=>'242','72'=>'246','73'=>'250','74'=>'000',
			'75'=>'254','76'=>'258','77'=>'260','78'=>'266','79'=>'270','80'=>'268','81'=>'276','82'=>'288','83'=>'292','84'=>'300','85'=>'304','86'=>'308','87'=>'312',
			'88'=>'316','89'=>'320','90'=>'324','91'=>'624','92'=>'328','93'=>'332','94'=>'334','95'=>'340','96'=>'344','97'=>'348','98'=>'352','99'=>'356','100'=>'360',
			'101'=>'364','102'=>'368','103'=>'372','104'=>'376','105'=>'380','106'=>'388','107'=>'392','108'=>'400','109'=>'398','110'=>'404','111'=>'296','112'=>'408',
			'113'=>'410','114'=>'414','115'=>'417','116'=>'418','117'=>'428','118'=>'422','119'=>'426','120'=>'430','121'=>'434','122'=>'438','123'=>'440','124'=>'442',
			'125'=>'446','126'=>'807','127'=>'450','128'=>'454','129'=>'458','130'=>'462','131'=>'466','132'=>'470','133'=>'584','134'=>'474','135'=>'478','136'=>'480',
			'137'=>'175','138'=>'484','139'=>'583','140'=>'498','141'=>'492','142'=>'496','143'=>'500','144'=>'504','145'=>'508','146'=>'104','147'=>'516','148'=>'520',
			'149'=>'524','150'=>'528','151'=>'000','152'=>'540','153'=>'554','154'=>'558','155'=>'562','156'=>'566','157'=>'570','158'=>'574','159'=>'580','160'=>'578',
			'161'=>'512','162'=>'586','163'=>'585','164'=>'591','165'=>'598','166'=>'600','167'=>'604','168'=>'608','169'=>'612','170'=>'616','171'=>'620','172'=>'630',
			'173'=>'634','174'=>'638','175'=>'642','176'=>'643','177'=>'646','178'=>'659','179'=>'662','180'=>'670','181'=>'882','182'=>'674','183'=>'678','184'=>'682',
			'185'=>'686','186'=>'690','187'=>'694','188'=>'702','189'=>'703','190'=>'705','191'=>'090','192'=>'706','193'=>'710','194'=>'239','195'=>'724','196'=>'144',
			'197'=>'654','198'=>'666','199'=>'729','200'=>'740','201'=>'744','202'=>'748','203'=>'752','204'=>'756','205'=>'760','206'=>'158','207'=>'762','208'=>'834',
			'209'=>'764','210'=>'768','211'=>'772','212'=>'776','213'=>'780','214'=>'788','215'=>'792','216'=>'795','217'=>'796','218'=>'798','219'=>'800','220'=>'804',
			'221'=>'784','222'=>'826','223'=>'840','224'=>'581','225'=>'858','226'=>'860','227'=>'548','228'=>'336','229'=>'862','230'=>'704','231'=>'092','232'=>'850',
			'233'=>'876','234'=>'732','235'=>'887','236'=>'000','237'=>'180','238'=>'894','239'=>'716','240'=>'384','241'=>'688','242'=>'499');
			 
			 /**************************************************/
			 
			 /************ Create Xml File formate ***************/
             
			// Euro currency Account
			 if($order_info['currency_id']==3)
			 {
			     $accountid = $this->config->get('cnp_login_euro');
			     $guid = $this->config->get('cnp_key_euro');
				 $mode = ucfirst($this->config->get('cnp_server_euro'));
			 }
			 
			 // Pound currency Account
			 if($order_info['currency_id']==1)
			 {
			     $accountid = $this->config->get('cnp_login_pound');
			     $guid = $this->config->get('cnp_key_pound');
				 $mode = ucfirst($this->config->get('cnp_server_pound'));
			 }
			 
			 // USD Currency Account
			if($order_info['currency_id']==2)
			 {
			      $accountid = $this->config->get('cnp_login');
			      $guid = $this->config->get('cnp_key');
				  $mode = ucfirst($this->config->get('cnp_server'));
			 }
			
			 
			 $dom = new DOMDocument('1.0', 'UTF-8');
             $root = $dom->createElement('CnPAPI', '');
             $root->setAttribute("xmlns","urn:APISchema.xsd");
             $root = $dom->appendChild($root);
			  
			 $version=$dom->createElement("Version","2.0");
    		 $version=$root->appendChild($version);
			 
			 $engine = $dom->createElement('Engine', '');
             $engine = $root->appendChild($engine);
			 
			 $application = $dom->createElement('Application','');
			 $application = $engine->appendChild($application);
    
			 $applicationid=$dom->createElement('ID','OpenCart');
			 $applicationid=$application->appendChild($applicationid);
			
			 $applicationname=$dom->createElement('Name','Salesforce:CnP_PaaS_SC_OpenCart');
			 $applicationid=$application->appendChild($applicationname);
			
			 $applicationversion=$dom->createElement('Version','CnP-2.0-OC-1.5.6.4');
			 $applicationversion=$application->appendChild($applicationversion);
    
    		 $request = $dom->createElement('Request', '');
    		 $request = $engine->appendChild($request);
    
    		 $operation=$dom->createElement('Operation','');
    		 $operation=$request->appendChild($operation);
			 
			 $operationtype=$dom->createElement('OperationType','Transaction');
    		 $operationtype=$operation->appendChild($operationtype);
    
    		 $ipaddress=$dom->createElement('IPAddress',$_SERVER['REMOTE_ADDR']);
    		 $ipaddress=$operation->appendChild($ipaddress);
    
			 $authentication=$dom->createElement('Authentication','');
    		 $authentication=$request->appendChild($authentication);
			
    		 $accounttype=$dom->createElement('AccountGuid',$guid ); 
    		 $accounttype=$authentication->appendChild($accounttype);
    
    		 $accountid=$dom->createElement('AccountID',$accountid );
    		 $accountid=$authentication->appendChild($accountid);
			 
			 $order=$dom->createElement('Order','');
    		 $order=$request->appendChild($order);
				
    		 $ordermode=$dom->createElement('OrderMode',$mode);
    		 $ordermode=$order->appendChild($ordermode);

    		/* $tracker=$dom->createElement('Tracker','Sample');
    		 $tracker=$order->appendChild($tracker);  */
    
    		 $cardholder=$dom->createElement('CardHolder','');
    		 $cardholder=$order->appendChild($cardholder);
			 
			 $billinginfo=$dom->createElement('BillingInformation','');
    		 $billinginfo=$cardholder->appendChild($billinginfo);

			 $billfirst_name=$dom->createElement('BillingFirstName',$order_info['payment_firstname']);
			 $billfirst_name=$billinginfo->appendChild($billfirst_name);
			
			 $billlast_name=$dom->createElement('BillingLastName',$order_info['payment_lastname']);
			 $billlast_name=$billinginfo->appendChild($billlast_name);
		
			 $bill_email=$dom->createElement('BillingEmail',$order_info['email']);
			 $bill_email=$billinginfo->appendChild($bill_email);
			
			 $bill_phone=$dom->createElement('BillingPhone',$order_info['telephone']);
			 $bill_phone=$billinginfo->appendChild($bill_phone);
		
			 $billingaddress=$dom->createElement('BillingAddress','');
			 $billingaddress=$cardholder->appendChild($billingaddress);
		
			 $billingaddress1=$dom->createElement('BillingAddress1',$order_info['payment_address_1']);
			 $billingaddress1=$billingaddress->appendChild($billingaddress1);
			
			 $billingaddress2=$dom->createElement('BillingAddress2',$order_info['payment_address_2']);
			 $billingaddress2=$billingaddress->appendChild($billingaddress2);
			
			 $billingaddress3=$dom->createElement('BillingAddress3','');
			 $billingaddress3=$billingaddress->appendChild($billingaddress3);
			
			 $billing_city=$dom->createElement('BillingCity',$order_info['payment_city']);
			 $billing_city=$billingaddress->appendChild($billing_city);
			
			 //$billing_state=$dom->createElement('BillingStateProvince',$order_info['payment_zone_code']);
			 //$billing_state=$billingaddress->appendChild($billing_state);
				
			 $billing_state=$dom->createElement('BillingStateProvince',$order_info['payment_zone']);
			 $billing_state=$billingaddress->appendChild($billing_state);
				
			if($order_info['payment_postcode'] != '')
			{
			 $billing_zip=$dom->createElement('BillingPostalCode',$order_info['payment_postcode']);
			 $billing_zip=$billingaddress->appendChild($billing_zip);
			}
			 $billing_country=$dom->createElement('BillingCountryCode',str_pad($opencart_country_code[$order_info['payment_country_id']], 3, "0", STR_PAD_LEFT));
			 $billing_country=$billingaddress->appendChild($billing_country);
			 
			 if($order_info['shipping_firstname'] != ''){
			 $shippinginfo=$dom->createElement('ShippingInformation','');
			 $shippinginfo=$cardholder->appendChild($shippinginfo);
			 
			 $shippingcontact=$dom->createElement('ShippingContactInformation','');
			 $shippingcontact=$shippinginfo->appendChild($shippingcontact);
	
			 $ship_first_name=$dom->createElement('ShippingFirstName',$order_info['shipping_firstname']);
			 $ship_first_name=$shippingcontact->appendChild($ship_first_name);
	
			 $ship_mi=$dom->createElement('ShippingMI', "");
			 $ship_mi=$shippingcontact->appendChild($ship_mi);
	
			 $ship_last_name=$dom->createElement('ShippingLastName',$order_info['shipping_lastname']);
			 $ship_last_name=$shippingcontact->appendChild($ship_last_name);

			 $ship_email=$dom->createElement('ShippingEmail',$order_info['email']);
			 $ship_email=$shippingcontact->appendChild($ship_email);	
	
			 $ship_phone=$dom->createElement('ShippingPhone',$order_info['telephone']);
			 $ship_phone=$shippingcontact->appendChild($ship_phone);    
		
			 $shippingaddress=$dom->createElement('ShippingAddress','');
			 $shippingaddress=$shippinginfo->appendChild($shippingaddress);
			
			 $ship_address1=$dom->createElement('ShippingAddress1',$order_info['shipping_address_1']);
			 $ship_address1=$shippingaddress->appendChild($ship_address1);
		
			 $ship_address2=$dom->createElement('ShippingAddress2',$order_info['shipping_address_2']);
			 $ship_address2=$shippingaddress->appendChild($ship_address2);
		
			 $ship_city=$dom->createElement('ShippingCity',$order_info['shipping_city']);
			 $ship_city=$shippingaddress->appendChild($ship_city);
		
			 $ship_state=$dom->createElement('ShippingStateProvince',$order_info['shipping_zone_code']);
			 $ship_state=$shippingaddress->appendChild($ship_state);
			
			if($order_info['shipping_postcode'] != '')
			{
			 $ship_zip=$dom->createElement('ShippingPostalCode',$order_info['shipping_postcode']);
			 $ship_zip=$shippingaddress->appendChild($ship_zip);
			} 
			 $ship_country=$dom->createElement('ShippingCountryCode',str_pad($opencart_country_code[$order_info['shipping_country_id']], 3, "0", STR_PAD_LEFT));
			 $ship_country=$shippingaddress->appendChild($ship_country);
			 }
			 
			 if($order_info['comment'] != '' || $order_info['fax'] !='' || $order_info['payment_company'] != '')
			 {
			 $customfieldlist = $dom->createElement('CustomFieldList','');
             $customfieldlist = $cardholder->appendChild($customfieldlist);
			 }if($order_info['comment'] != ''){
			 $customfield = $dom->createElement('CustomField','');
			 $customfield = $customfieldlist->appendChild($customfield);
			
			 $fieldname = $dom->createElement('FieldName','Comments');
			 $fieldname = $customfield->appendChild($fieldname);
			
			 $fieldvalue = $dom->createElement('FieldValue',substr($order_info['comment'], 0, 50));
			 $fieldvalue = $customfield->appendChild($fieldvalue);
			 } if($order_info['fax'] !=''){
			 $customfield1 = $dom->createElement('CustomField','');
			 $customfield1 = $customfieldlist->appendChild($customfield1);
			
			 $fieldname1 = $dom->createElement('FieldName','Customer Fax');
			 $fieldname1 = $customfield1->appendChild($fieldname1);
			 
			 $fieldvalue1 = $dom->createElement('FieldValue',substr($order_info['fax'], 0, 50));
			 $fieldvalue1 = $customfield1->appendChild($fieldvalue1);
			 } if($order_info['payment_company'] != ''){
			 $customfield2 = $dom->createElement('CustomField','');
			 $customfield2 = $customfieldlist->appendChild($customfield2);
			
			 $fieldname2 = $dom->createElement('FieldName','Billing Company');
			 $fieldname2 = $customfield2->appendChild($fieldname2);
	
			 $fieldvalue2 = $dom->createElement('FieldValue',substr($order_info['payment_company'], 0, 50));
			 $fieldvalue2 = $customfield2->appendChild($fieldvalue2);
			 } if($order_info['shipping_company'] != ''){
			 $customfield3 = $dom->createElement('CustomField','');
			 $customfield3 = $customfieldlist->appendChild($customfield3);
	
			 $fieldname3 = $dom->createElement('FieldName','Shipping Company');
			 $fieldname3 = $customfield3->appendChild($fieldname3);
	
			 $fieldvalue3 = $dom->createElement('FieldValue',substr($order_info['shipping_company'], 0, 50));
			 $fieldvalue3 = $customfield3->appendChild($fieldvalue3);
			 }
			 
			 $paymentmethod=$dom->createElement('PaymentMethod','');
			 $paymentmethod=$cardholder->appendChild($paymentmethod);
			
			 if($this->request->post['payment_methods'] == 'Creditcard')
			 
			 {
			
			 $payment_type=$dom->createElement('PaymentType','CreditCard');
			 $payment_type=$paymentmethod->appendChild($payment_type);
			
			 $creditcard=$dom->createElement('CreditCard','');
			 $creditcard=$paymentmethod->appendChild($creditcard);
				
			 $credit_name=$dom->createElement('NameOnCard',$this->request->post['cc_owner']);
			 $credit_name=$creditcard->appendChild($credit_name);
			
			 $credit_number=$dom->createElement('CardNumber',str_replace(' ', '', $this->request->post['cc_number']));
			 $credit_number=$creditcard->appendChild($credit_number);
			
			 $credit_cvv=$dom->createElement('Cvv2',$this->request->post['cc_cvv2']);
			 $credit_cvv=$creditcard->appendChild($credit_cvv);
			 
			 $credit_expdate=$dom->createElement('ExpirationDate',$this->request->post['cc_expire_date_month'] ."/" .substr($this->request->post['cc_expire_date_year'],2,2));
			 $credit_expdate=$creditcard->appendChild($credit_expdate);
			
			 }
			 
	 if($this->request->post['payment_methods'] == 'eCheck')
	 {

	 $payment_type=$dom->createElement('PaymentType','Check');
	 $payment_type=$paymentmethod->appendChild($payment_type);
	 
	 $echeck=$dom->createElement('Check','');
	 $echeck=$paymentmethod->appendChild($echeck);
	 
	 $AccountNumber=$dom->createElement('AccountNumber',$this->request->post['AccountNumber']);
	 $AccountNumber=$echeck->appendChild($AccountNumber);
	 
	 $AccountType=$dom->createElement('AccountType',$this->request->post['AccountType']);
	 $AccountType=$echeck->appendChild($AccountType);
	 
	 $RoutingNumber=$dom->createElement('RoutingNumber',$this->request->post['RoutingNumber']);
	 $RoutingNumber=$echeck->appendChild($RoutingNumber);
	 
	 $CheckNumber=$dom->createElement('CheckNumber',$this->request->post['CheckNumber']);
	 $CheckNumber=$echeck->appendChild($CheckNumber);

	 $CheckType=$dom->createElement('CheckType',$this->request->post['CheckType']);
	 $CheckType=$echeck->appendChild($CheckType);
	 
	 $NameOnAccount=$dom->createElement('NameOnAccount',str_replace('&', '&amp;',$this->request->post['NameOnAccount']));
	 $NameOnAccount=$echeck->appendChild($NameOnAccount);
	 
 
	 }			
		
	 if($this->request->post['payment_methods'] == 'Invoice')
	 {
	 
	 $payment_type=$dom->createElement('PaymentType','Invoice');
	 $payment_type=$paymentmethod->appendChild($payment_type);
	 
	 $invoice=$dom->createElement('Invoice','');
	 $invoice=$paymentmethod->appendChild($invoice);
	 
	 $CheckNumber=$dom->createElement('InvoiceCheckNumber',$this->request->post['InvoiceCheckNumber']);
	 $CheckNumber=$invoice->appendChild($CheckNumber);
	 
	 }
	
	 if($this->request->post['payment_methods'] == 'PurchaseOrder')
	 {
	 
	 $payment_type=$dom->createElement('PaymentType','PurchaseOrder');
	 $payment_type=$paymentmethod->appendChild($payment_type);
	 
	 $PurchaseOrder=$dom->createElement('PurchaseOrder','');
	 $PurchaseOrder=$paymentmethod->appendChild($PurchaseOrder);
	 
	 $CheckNumber=$dom->createElement('PurchaseOrderNumber',$this->request->post['PurchaseOrderNumber']);
	 $CheckNumber=$PurchaseOrder->appendChild($CheckNumber);
	 
	 }
		 
			 
			 $orderitemlist=$dom->createElement('OrderItemList','');
             $orderitemlist=$order->appendChild($orderitemlist);
			 
			 //$this->load->model('checkout/extension');
			 if(isset($_POST['indefinite_times']))$number_of_times = $_POST['indefinite_times'];
			 else if(isset($_POST['number_of_times']))$number_of_times = $_POST['number_of_times']; else $number_of_times = 0;
			 $product = $this->cart->getProducts();
			 $total=0;
			 $handling_data = array();
			 $reward_data = array();
			 $ship_data = array();
			 $tax_data = array();
			 $coupon_data = array();
			 $voucher_data = array();
			 $subtotal_data = array();
			 $total_data = array();
			 $loworderfee_data = array();
			 $taxes = $this->cart->getTaxes();
			 //$results = $this->model_checkout_extension->getExtensions('total');
				if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {						 
				$this->load->model('setting/extension');
				
				$sort_order = array(); 
				
				$results = $this->model_setting_extension->getExtensions('total');
				
				foreach ($results as $key => $value) {
					$sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
				}
				
				array_multisort($sort_order, SORT_ASC, $results);
			}
			 foreach ($results as $result) {
					if ($this->config->get($result['code'] . '_status')) {
						if($result['code'] == "handling")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($handling_data, $total, $taxes);
						}
						if($result['code'] == "low_order_fee")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($loworderfee_data, $total, $taxes);
						}
						 
						if($result['code'] == "reward")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($reward_data, $total, $taxes);
						}
					 
						if($result['code'] == "shipping")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($ship_data, $total, $taxes);
						}
						if($result['code'] == "tax")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($tax_data, $total, $taxes);
						}
						if($result['code'] == "coupon")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($coupon_data, $total, $taxes);
						}
						if($result['code'] == "voucher")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($voucher_data, $total, $taxes);
						}
						if($result['code'] == "sub_total")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($subtotal_data, $total, $taxes);
						}
						if($result['code'] == "total")
						{
						   $this->load->model('total/' . $result['code']);
						   $this->{'model_total_' . $result['code']}->getTotal($total_data, $total, $taxes);
						}
					
					
					}			 
				 
		     }			 
		
			
			
			 $pound = $this->currency->getSymbolLeft();
			 $dollor = $this->currency->getSymbolRight();
			 $exp=array($pound,$dollor,",","-");
			 $exchange_rate = number_format($this->currency->getValue($this->currency->getCode()), 4, '.', '');
			 //echo $exchange_rate = $this->currency->format('9.99', $this->currency->getCode(), $exchange_rate,false)/10;
			  if(isset($reward_data) && !empty($reward_data))
			 {
					 foreach($reward_data as $reward)
					 {
					      $reward_name  = $reward['title'];
						 // $shipp_value = str_replace($exp,"",$ship['text'])*100;
						 $reward_value = str_replace($exp,"",$reward['value']);
						 
						 //$reward_value = $reward['value']*100;
						
					 }
			 }else{
			       $reward_name = "";
			       $reward_value = 000;
			 }
			 if(isset($total_data) && !empty($total_data))
			 {
					 foreach($total_data as $total_disp)
					 {
					      $total_disp_name  = $total_disp['title'];
						 // $shipp_value = str_replace($exp,"",$ship['text'])*100;
						 $total_disp_value = str_replace($exp,"",$total_disp['text'])*100;
						 $total_disp_sortvalue = $total_disp['sort_order'];
						
					 }
			 }else{
			       $total_disp_name= "";
			       $total_disp_value = 000;
			 }
			
			 if(isset($ship_data) && !empty($ship_data))
			 {
					 foreach($ship_data as $ship)
					 {
					      $shipp_name  = $ship['title'];
						 // $shipp_value = str_replace($exp,"",$ship['text'])*100;
						 $shipp_value = $ship['value'];
						
					 }
			 }else{
			       $shipp_name = "";
			       $shipp_value = 000;
			 }
			
			$tax_value =0;
			 if(isset($tax_data) && !empty($tax_data))
			 {
					 foreach($tax_data as $tax)
					 {
					      $tax_name = $tax['title'];
						  $tax_value1 = str_replace($exp,"",$tax['text']);
						  $tax_value = $tax_value1 + $tax_value;
					 }
			 }else{
			       $tax_value = 000;
			 }
			
			 if(isset($coupon_data) && !empty($coupon_data))
			 {
					 foreach($coupon_data as $coupon)
					 {
					      $coupon_name = $coupon['title'];
						  $coupon_code = $this->session->data['coupon'];
						  $coupon_value = str_replace($exp,"",$coupon['text']);
					 }
			 }else{
			       $coupon_value = 000;
				   $coupon_code='';
			 }
			 
			 
			 if(isset($voucher_data) && !empty($voucher_data))
			 {
					 foreach($voucher_data as $voucher)
					 {
					      $voucher_name = $voucher['title'];
						  $voucher_code = $this->session->data['voucher'];
						  $voucher_value = str_replace($exp,"",$voucher['text']);
					 }
			 }else{
			       $voucher_value = 000;
				   $voucher_code='';
			 }
			
			  if(isset($handling_data) && !empty($handling_data))
			 {	
			 
					 foreach($handling_data as $handling)
					 {
							if($handling['sort_order'] < $total_disp_sortvalue){
					      $handling_name  = $handling['title'];
						 // $shipp_value = str_replace($exp,"",$ship['text'])*100;
						 $handling_value = $handling['value'];
						
						 $handling_id ="001";
						 $handling_quantity ="1";
						 $handling_sku="SKUHANDLING";
						 }
						 else{
						  $handling_name = "";
			        $handling_value = 000;
				    $handling_id =00;
					$handling_quantity ="";
					$handling_sku="";
						 
						 
						 }
						
					 }
			 }else{
			       $handling_name = "";
			       $handling_value = 000;
				    $handling_id =0;
					$handling_quantity ="";
					$handling_sku="";
			 }
			 
			 if(isset($loworderfee_data) && !empty($loworderfee_data))
			 {
					 foreach($loworderfee_data as $loworderfee)
					 {
						if($loworderfee['sort_order'] < $total_disp_sortvalue){
					      $loworderfee_name  = $loworderfee['title'];
						
						 $loworderfee_value = $loworderfee['value'];
						 
						 $loworderfee_id ="002";
						 $loworderfee_quantity ="1";
						 $loworderfee_sku = "SKUORDERFEE";
						} else{
						
						   $loworderfee_name = "";
						   $loworderfee_value = 000;
						   $loworderfee_id ="";
						   $loworderfee_quantity ="";
						   $loworderfee_sku = "";
						
						
						
						}
						
					 }
			 }else{
			       $loworderfee_name = "";
			       $loworderfee_value = 000;
				   $loworderfee_id ="";
				   $loworderfee_quantity ="";
				   $loworderfee_sku = "";
			 }
		
			
			
			 	$this->load->model('catalog/product');	
			 $tm_amt=0;
			
			
			 if(isset($handling_data) && $handling_name!="" && isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1 && isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment'){
			
				 $orderitem=$dom->createElement('OrderItem','');
				 $orderitem=$orderitemlist->appendChild($orderitem);
				 
				 $itemid=$dom->createElement('ItemID',substr($handling_id, 0, 25));
				 $itemid=$orderitem->appendChild($itemid);
				 
				 $itemname=$dom->createElement('ItemName',substr($handling_name, 0, 25));
				 $itemname=$orderitem->appendChild($itemname);
				
				 $quntity=$dom->createElement('Quantity',$handling_quantity);
				 $quntity=$orderitem->appendChild($quntity);

				 $round_price = round(($handling_value*$exchange_rate)/$number_of_times, 2);
				 $unitprice=$dom->createElement('UnitPrice',$this->floor_dec($round_price,2,'.','')*100);
				 $unitprice=$orderitem->appendChild($unitprice);
				 
				 $unit_deduct=$dom->createElement('UnitDeductible','000');
				 $unit_deduct=$orderitem->appendChild($unit_deduct);
				
				 $unit_tax=$dom->createElement('UnitTax','000');
				 $unit_tax=$orderitem->appendChild($unit_tax);
				
				 $unit_disc=$dom->createElement('UnitDiscount','000');
				 $unit_disc=$orderitem->appendChild($unit_disc);
				
				 
				 $sku_code=$dom->createElement('SKU',substr($handling_sku, 0, 25));
				 $sku_code=$orderitem->appendChild($sku_code);
			
			}
			if(isset($handling_data) && $handling_name!="" && !(isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1 && isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment')){
			
				 $orderitem=$dom->createElement('OrderItem','');
				 $orderitem=$orderitemlist->appendChild($orderitem);
				 
				 $itemid=$dom->createElement('ItemID',substr($handling_id, 0, 25));
				 $itemid=$orderitem->appendChild($itemid);
				 
				 $itemname=$dom->createElement('ItemName',substr($handling_name, 0, 25));
				 $itemname=$orderitem->appendChild($itemname);
				
				 $quntity=$dom->createElement('Quantity',$handling_quantity);
				 $quntity=$orderitem->appendChild($quntity);

				 $round_price = round($handling_value*$exchange_rate, 2);
				 $unitprice=$dom->createElement('UnitPrice',($round_price)*100);
				 $unitprice=$orderitem->appendChild($unitprice);
				 
				 $unit_deduct=$dom->createElement('UnitDeductible','000');
				 $unit_deduct=$orderitem->appendChild($unit_deduct);
				
				 $unit_tax=$dom->createElement('UnitTax','000');
				 $unit_tax=$orderitem->appendChild($unit_tax);
				
				 $unit_disc=$dom->createElement('UnitDiscount','000');
				 $unit_disc=$orderitem->appendChild($unit_disc);
				
				 
				 $sku_code=$dom->createElement('SKU',substr($handling_sku, 0, 25));
				 $sku_code=$orderitem->appendChild($sku_code);

			}
			if(isset($loworderfee_data) && $loworderfee_name!="" && isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1 && isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment'){
			
				 $orderitem=$dom->createElement('OrderItem','');
				 $orderitem=$orderitemlist->appendChild($orderitem);
				 
				 $itemid=$dom->createElement('ItemID',substr($loworderfee_id, 0, 25));
				 $itemid=$orderitem->appendChild($itemid);
				 
				 $itemname=$dom->createElement('ItemName',substr($loworderfee_name, 0, 25));
				 $itemname=$orderitem->appendChild($itemname);
				
				 $quntity=$dom->createElement('Quantity',$loworderfee_quantity);
				 $quntity=$orderitem->appendChild($quntity);
				 
				 $round_price = round(($loworderfee_value*$exchange_rate)/$number_of_times, 2);
				 $unitprice=$dom->createElement('UnitPrice',$this->floor_dec($round_price,2,'.','')*100);
				 $unitprice=$orderitem->appendChild($unitprice);
				 
				 $unit_deduct=$dom->createElement('UnitDeductible','000');
				 $unit_deduct=$orderitem->appendChild($unit_deduct);
				
				 $unit_tax=$dom->createElement('UnitTax','000');
				 $unit_tax=$orderitem->appendChild($unit_tax);
				
				 $unit_disc=$dom->createElement('UnitDiscount','000');
				 $unit_disc=$orderitem->appendChild($unit_disc);
				
				 
				 $sku_code=$dom->createElement('SKU',substr($loworderfee_sku, 0, 25));
				 $sku_code=$orderitem->appendChild($sku_code);
			
			}
			if(isset($loworderfee_data) && $loworderfee_name!="" && !(isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1 && isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment')){
			
				 $orderitem=$dom->createElement('OrderItem','');
				 $orderitem=$orderitemlist->appendChild($orderitem);
				 
				 $itemid=$dom->createElement('ItemID',substr($loworderfee_id, 0, 25));
				 $itemid=$orderitem->appendChild($itemid);
				 
				 $itemname=$dom->createElement('ItemName',substr($loworderfee_name, 0, 25));
				 $itemname=$orderitem->appendChild($itemname);
				
				 $quntity=$dom->createElement('Quantity',$loworderfee_quantity);
				 $quntity=$orderitem->appendChild($quntity);
				
				 $round_price = round($loworderfee_value*$exchange_rate, 2);
				 $unitprice=$dom->createElement('UnitPrice',$round_price*100);
				 $unitprice=$orderitem->appendChild($unitprice);
				 
				 $unit_deduct=$dom->createElement('UnitDeductible','000');
				 $unit_deduct=$orderitem->appendChild($unit_deduct);
				
				 $unit_tax=$dom->createElement('UnitTax','000');
				 $unit_tax=$orderitem->appendChild($unit_tax);
				
				 $unit_disc=$dom->createElement('UnitDiscount','000');
				 $unit_disc=$orderitem->appendChild($unit_disc);
				
				 
				 $sku_code=$dom->createElement('SKU',substr($loworderfee_sku, 0, 25));
				 $sku_code=$orderitem->appendChild($sku_code);
  
  			}
			
			if(isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1 && isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment')
			{
			 foreach($product as $pro)
			 {
			 
				 $product_info = $this->model_catalog_product->getProduct(substr($pro['product_id'], 0, 25));
				
				 $orderitem=$dom->createElement('OrderItem','');
				 $orderitem=$orderitemlist->appendChild($orderitem);
				
				 $itemid=$dom->createElement('ItemID',substr($pro['product_id'], 0, 25));
				 $itemid=$orderitem->appendChild($itemid);
				 
				 $itemname=$dom->createElement('ItemName',substr($pro['name'], 0, 25));
				 $itemname=$orderitem->appendChild($itemname);
				
				 $quntity=$dom->createElement('Quantity',$pro['quantity']);
				 $quntity=$orderitem->appendChild($quntity);
				 
				 $round_price = round(($pro['price']*$exchange_rate), 2);
				 $unitprice=$dom->createElement('UnitPrice',$this->floor_dec($round_price/$number_of_times,2,'.','')*100);
				 $unitprice=$orderitem->appendChild($unitprice);
				 
				 $unit_deduct=$dom->createElement('UnitDeductible','000');
				 $unit_deduct=$orderitem->appendChild($unit_deduct);
				
				 $unit_tax=$dom->createElement('UnitTax','000');
				 $unit_tax=$orderitem->appendChild($unit_tax);
				
				 $unit_disc=$dom->createElement('UnitDiscount','000');
				 $unit_disc=$orderitem->appendChild($unit_disc);
				 if($product_info['sku']==""){
					$sku_name=$pro['product_id'];				
				}else  {
					$sku_name=$product_info['sku'];
				}
				 
				 $sku_code=$dom->createElement('SKU',substr($sku_name, 0, 25));
				 $sku_code=$orderitem->appendChild($sku_code);
				 
				//echo $tm_amt +=$pro['quantity']*($this->floor_dec(($pro['price']/$number_of_times),2,'.',''))*100; //chnaged on 8/8/14
				 $tm_amt +=$pro['quantity']*($this->floor_dec(($round_price/$number_of_times),2,'.',''))*100; 
			      
			 }
			
			
			 $total_cou_rew =  ($coupon_value + $reward_value +$voucher_value)/$number_of_times;
			 if($coupon_value != 0 || $reward_value != 0)$totaldis_value = $this->floor_dec(($coupon_value + $reward_value)/$number_of_times,2,'.','')*100;
			 else $totaldis_value = 0;
			}else{
			
			 foreach($product as $pro)
			 {
			 
				 $product_info = $this->model_catalog_product->getProduct(substr($pro['product_id'], 0, 25));
				
				 $orderitem=$dom->createElement('OrderItem','');
				 $orderitem=$orderitemlist->appendChild($orderitem);
				
				 $itemid=$dom->createElement('ItemID',substr($pro['product_id'], 0, 25));
				 $itemid=$orderitem->appendChild($itemid);
				 
				 $itemname=$dom->createElement('ItemName',substr($pro['name'], 0, 25));
				 $itemname=$orderitem->appendChild($itemname);
				
				 $quntity=$dom->createElement('Quantity',$pro['quantity']);
				 $quntity=$orderitem->appendChild($quntity);

				 $round_price = round($pro['price']*$exchange_rate, 2);
				 $unitprice=$dom->createElement('UnitPrice',$round_price*100);
				 $unitprice=$orderitem->appendChild($unitprice);				
				 
				 $unit_deduct=$dom->createElement('UnitDeductible','000');
				 $unit_deduct=$orderitem->appendChild($unit_deduct);
				
				 $unit_tax=$dom->createElement('UnitTax','000');
				 $unit_tax=$orderitem->appendChild($unit_tax);
				
				 $unit_disc=$dom->createElement('UnitDiscount','000');
				 $unit_disc=$orderitem->appendChild($unit_disc);
				 if($product_info['sku']==""){
					$sku_name=$pro['product_id'];				
				}else  {
					$sku_name=$product_info['sku'];
				}
				 
				 $sku_code=$dom->createElement('SKU',substr($sku_name, 0, 25));
				 $sku_code=$orderitem->appendChild($sku_code);
				 
				 //$tm_amt +=$pro['quantity']*$pro['price']*100; chnaged on 8/8/14
				 $tm_amt +=$pro['quantity']*$round_price*100;
			      
			 }
			
			
			 $total_cou_rew = $coupon_value + $reward_value +$voucher_value;
			 $totaldis_value = $coupon_value + $reward_value;
			
			}
			 //$tm_amt +=($shipp_value)+($tax_value)-$totaldis_value ;
			
			 $shipping=$dom->createElement('Shipping','');
		     $shipping=$order->appendChild($shipping);
				
			 $shipping_method=$dom->createElement('ShippingMethod',$shipp_name);
			 $shipping_method=$shipping->appendChild($shipping_method);
			if(isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment')
			{
			 $round_shipping_price = round(($shipp_value*$exchange_rate), 2);
			 $shipping_value=$dom->createElement('ShippingValue',$this->floor_dec($round_shipping_price/$number_of_times,2,'.','')*100);
			 $shipping_value=$shipping->appendChild($shipping_value);
			}else{
			 $round_shipping_price = round($shipp_value*$exchange_rate, 2);
			 $shipping_value=$dom->createElement('ShippingValue',$round_shipping_price*100);
			 $shipping_value=$shipping->appendChild($shipping_value);
		     }
			 $shipping_tax=$dom->createElement('ShippingTax','000');
			 $shipping_tax=$shipping->appendChild($shipping_tax);
			
			
			 $receipt=$dom->createElement('Receipt','');
			 $receipt=$order->appendChild($receipt);
			
			 $recipt_lang=$dom->createElement('Language','ENG');
			 $recipt_lang=$receipt->appendChild($recipt_lang);
			
			if(trim($this->config->get('clickandpledge_org_info')) != '')
			 {
			 $recipt_org=$dom->createElement('OrganizationInformation',substr(str_replace('&', '&amp;',addslashes(html_entity_decode($this->config->get('clickandpledge_org_info')))),0,1500));
			 $recipt_org=$receipt->appendChild($recipt_org);
			 }
			if(trim($this->config->get('clickandpledge_thank_you')) != '')
			 {
			 $recipt_thanks=$dom->createElement('ThankYouMessage',substr(str_replace('&','&amp;',addslashes(html_entity_decode($this->config->get('clickandpledge_thank_you')))),0,500));
			 $recipt_thanks=$receipt->appendChild($recipt_thanks);
			 }
			if(trim($this->config->get('clickandpledge_terms_conditions')) != '')
			 {
			 $recipt_terms=$dom->createElement('TermsCondition',substr(str_replace('&','&amp;',addslashes(html_entity_decode($this->config->get('clickandpledge_terms_conditions')))),0,1500));
			 $recipt_terms=$receipt->appendChild($recipt_terms);
			}
			 $recipt_deduct=$dom->createElement('Deductible','1');
			 $recipt_deduct=$receipt->appendChild($recipt_deduct);
			
			if(trim($this->config->get('clickandpledge_send_receipt')) == 'yes')
			{
			 $recipt_email=$dom->createElement('EmailNotificationList','');
			 $recipt_email=$receipt->appendChild($recipt_email);
		
			 $email_note=$dom->createElement('NotificationEmail',$order_info['email']);
			 $email_note=$recipt_email->appendChild($email_note);
			 
			 }
			 
			 $transation=$dom->createElement('Transaction','');
	         $transation=$order->appendChild($transation);

	         $trans_type=$dom->createElement('TransactionType','Payment');
	         $trans_type=$transation->appendChild($trans_type);
	        
			 $trans_desc=$dom->createElement('DynamicDescriptor','DynamicDescriptor');
			 $trans_desc=$transation->appendChild($trans_desc); 
			 
			 if(isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1){
		
			 $trans_recurr=$dom->createElement('Recurring','');
			 $trans_recurr=$transation->appendChild($trans_recurr);
			 
			 $total_installment=$dom->createElement('Installment',$number_of_times);
			 $total_installment=$trans_recurr->appendChild($total_installment);
			 
			 $total_periodicity=$dom->createElement('Periodicity',$_POST['Periodicity']);
			 $total_periodicity=$trans_recurr->appendChild($total_periodicity);
			 
			 $total_installment=$dom->createElement('RecurringMethod',$_POST['recurring_method']);
			 $total_installment=$trans_recurr->appendChild($total_installment);
			 
			 }
			if(isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1 && isset($_POST['recurring_method']) && $_POST['recurring_method'] == 'Installment')
			{
			 if($handling_value != 0)$handling_recurring = $this->floor_dec(($handling_value/$number_of_times),2,'.','')*100;else $handling_recurring = 0;
			 if($loworderfee_value != 0)$loworderfee_value   = $this->floor_dec(($loworderfee_value/$number_of_times),2,'.','')*100;else $loworderfee_value = 0;
			 if($shipp_value !=0)$shipp_value = $this->floor_dec(($round_shipping_price/$number_of_times),2,'.','')*100;else $shipp_value =0;
			 if($tax_value != 0) $tax_value =  $this->floor_dec(($tax_value/$number_of_times),2,'.','')*100;else $tax_value =0;
			 if($voucher_value != 0) $voucher_value = $this->floor_dec(($voucher_value/$number_of_times),2,'.','')*100;else $voucher_value =0;
			 $recurring_total = ($handling_recurring + $loworderfee_value + $tm_amt + $shipp_value + $tax_value) - ($totaldis_value + $voucher_value);
			 
			 $trans_totals=$dom->createElement('CurrentTotals','');
			 $trans_totals=$transation->appendChild($trans_totals);
			
			 $total_discount=$dom->createElement('TotalDiscount',$totaldis_value);
			 $total_discount=$trans_totals->appendChild($total_discount);
		
			 $total_tax=$dom->createElement('TotalTax',$tax_value);
			 $total_tax=$trans_totals->appendChild($total_tax);
		
			 $total_ship=$dom->createElement('TotalShipping',$shipp_value);
			 $total_ship=$trans_totals->appendChild($total_ship);
			
			 $total_deduct=$dom->createElement('TotalDeductible','000');
			 $total_deduct=$trans_totals->appendChild($total_deduct);
		
			 $total_amount=$dom->createElement('Total',$recurring_total);
			 $total_amount=$trans_totals->appendChild($total_amount);
			 
			 $trans_coupon=$dom->createElement('CouponCode',$coupon_code);
			 $trans_coupon=$transation->appendChild($trans_coupon);
			 
			 $trans_coupon_discount=$dom->createElement('TransactionDiscount',$totaldis_value);
			 $trans_coupon_discount=$transation->appendChild($trans_coupon_discount);
			 
			 $trans_tax=$dom->createElement('TransactionTax',$tax_value);
	         $trans_tax=$transation->appendChild($trans_tax);
			 
			 $giftcardlist=$dom->createElement('GiftCardList','');
	         $giftcardlist=$transation->appendChild($giftcardlist);
			 
			 $giftcard=$dom->createElement('GiftCard','');
	         $giftcard=$giftcardlist->appendChild($giftcard);
			 
			 $giftcardcode=$dom->createElement('GiftCardCode',$voucher_code);
	         $giftcardcode=$giftcard->appendChild($giftcardcode);
			 
			 $giftcardamount=$dom->createElement('GiftCardAmount',$voucher_value);
	         $giftcardamount=$giftcard->appendChild($giftcardamount); 
			 
			 }
			 else{
			 // "@@l".$loworderfee_value."@@p".$tm_amt."@@s".$round_shipping_price."@@t".$tax_value."@@d".$totaldis_value."@@v".$voucher_value;
			 $grand_total = ($loworderfee_value + $tm_amt + ($round_shipping_price*100) + ($tax_value*100)) - ($totaldis_value*100 + $voucher_value*100);
			 $grand_total = round($grand_total,2);
			 $trans_totals=$dom->createElement('CurrentTotals','');
			 $trans_totals=$transation->appendChild($trans_totals);
			
			 $total_discount=$dom->createElement('TotalDiscount',$totaldis_value*100);
			 $total_discount=$trans_totals->appendChild($total_discount);
		
			 $total_tax=$dom->createElement('TotalTax',$tax_value*100);
			 $total_tax=$trans_totals->appendChild($total_tax);
		
			 $total_ship=$dom->createElement('TotalShipping',$round_shipping_price*100);
			 $total_ship=$trans_totals->appendChild($total_ship);
			
			 $total_deduct=$dom->createElement('TotalDeductible','000');
			 $total_deduct=$trans_totals->appendChild($total_deduct);
		
			 $total_amount=$dom->createElement('Total',$grand_total);
			 $total_amount=$trans_totals->appendChild($total_amount);
			 
			 $trans_coupon=$dom->createElement('CouponCode',$coupon_code);
			 $trans_coupon=$transation->appendChild($trans_coupon);
			 
			 $trans_coupon_discount=$dom->createElement('TransactionDiscount',$totaldis_value*100);
			 $trans_coupon_discount=$transation->appendChild($trans_coupon_discount);
			 
			 $trans_tax=$dom->createElement('TransactionTax',$tax_value*100);
	         $trans_tax=$transation->appendChild($trans_tax);
			 
			 $giftcardlist=$dom->createElement('GiftCardList','');
	         $giftcardlist=$transation->appendChild($giftcardlist);
			 
			 $giftcard=$dom->createElement('GiftCard','');
	         $giftcard=$giftcardlist->appendChild($giftcard);
			 
			 $giftcardcode=$dom->createElement('GiftCardCode',$voucher_code);
	         $giftcardcode=$giftcard->appendChild($giftcardcode);
			 
			 $giftcardamount=$dom->createElement('GiftCardAmount',$voucher_value*100);
	         $giftcardamount=$giftcard->appendChild($giftcardamount); 

			 }
			 $response=array();
	         $strParam =$dom->saveXML();
			 $connect = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
			 $client = new SoapClient('https://paas.cloud.clickandpledge.com/paymentservice.svc?wsdl', $connect);
			 $params = array('instruction'=>$strParam);
			 // print_r($strParam);
			 $response = $client->Operation($params);
			 $response_value=$response->OperationResult->ResultData;
	         $result_array=$response->OperationResult->ResultCode;
			
	         $transation_number=$response->OperationResult->TransactionNumber;
	         $xml_error=explode(":",$response->OperationResult->AdditionalInfo);			 
	         $json = array();
			 if(isset($xml_error['2']))
	         {
       				$payment_error=$xml_error['2'];
			 }else{
	   				$payment_error="";
			 }
			 
			 if($payment_error=='')
	         {
		          $response_value=$response->OperationResult->ResultData;
				  if($result_array=='00')
		          {
				      $report = "Transaction Id:".$transation_number;
				      $this->model_checkout_order->confirm($this->session->data['order_id'], $this->config->get('config_order_status_id'),$report);

				       $message = $response_value;
				  
				       $this->model_checkout_order->update($this->session->data['order_id'], 15, $message, FALSE);

					   $json['success'] = $this->url->link('checkout/success', '', 'SSL');
				  }else{
			          $json['error'] = $response_value;
			     }
			 }else{
			       $json['error'] = $payment_error;
			}
	   

		$this->response->setOutput(json_encode($json));
	 }
}

?>