<?php
class ControllerPaymentCnP extends Controller{

     private $error = array(); 

     public function index() {
		$this->load->language('payment/cnp');
		
		//$this->document->title = $this->language->get('heading_title');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {			
			$this->model_setting_setting->editSetting('cnp', $this->request->post);				
			
			$this->session->data['success'] = $this->language->get('text_success');

			$this->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
		}
        
		$this->data['heading_title'] = $this->language->get('heading_title');
		$this->data['text_enabled'] = $this->language->get('text_enabled');
		$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_all_zones'] = $this->language->get('text_all_zones');
		$this->data['text_yes'] = $this->language->get('text_yes');
		$this->data['text_no'] = $this->language->get('text_no');
		$this->data['text_live'] = $this->language->get('text_live');
		$this->data['text_test'] = $this->language->get('text_test');
		
		$this->data['entry_login'] = $this->language->get('entry_login');
		$this->data['entry_key'] = $this->language->get('entry_key');
		$this->data['entry_mode'] = $this->language->get('entry_mode');
		$this->data['entry_status'] = $this->language->get('entry_status');
		
		//Other settings
		$this->data['organization_information'] = $this->language->get('organization_information');
		$this->data['thank_you_message'] = $this->language->get('thank_you_message');
		$this->data['terms_conditions'] = $this->language->get('terms_conditions');
		$this->data['receipt_setting'] = $this->language->get('receipt_setting');
		$this->data['payment_methods'] = $this->language->get('payment_methods');
		$this->data['payment_method_default'] = $this->language->get('payment_method_default');
		
		//recurring contribuction
		$this->data['clickandpledge_recurring_contribution'] = $this->language->get('clickandpledge_recurring_contribution');

		$this->data['clickandpledge_week'] = $this->language->get('clickandpledge_week');
		$this->data['clickandpledge_2_weeks'] = $this->language->get('clickandpledge_2_weeks');
		$this->data['clickandpledge_month'] = $this->language->get('clickandpledge_month');
		$this->data['clickandpledge_2_months'] = $this->language->get('clickandpledge_2_months');
		$this->data['clickandpledge_quarter'] = $this->language->get('clickandpledge_quarter');
		$this->data['clickandpledge_6_months'] = $this->language->get('clickandpledge_6_months');
		$this->data['clickandpledge_year'] = $this->language->get('clickandpledge_year');
		
		$this->data['clickandpledge_installment'] = $this->language->get('clickandpledge_installment');
		$this->data['clickandpledge_subscription'] = $this->language->get('clickandpledge_subscription');
		$this->data['clickandpledge_indefinite'] = $this->language->get('clickandpledge_indefinite');
		
		$this->data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');
		
		$this->data['tab_general'] = $this->language->get('tab_general');
		
		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}
		
		if (isset($this->error['login'])) {
			$this->data['error_login'] = $this->error['login'];
		} else {
			$this->data['error_login'] = '';
		}
		
		if (isset($this->error['key'])) {
			$this->data['error_key'] = $this->error['key'];
		} else {
			$this->data['error_key'] = '';
		}
		
		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('payment/cnp', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
		$this->data['action'] = $this->url->link('payment/cnp', 'token=' . $this->session->data['token'], 'SSL');
		
		$this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');
		
		if (isset($this->request->post['cnp_login'])) {
			$this->data['cnp_login'] = $this->request->post['cnp_login'];
		} else {
			$this->data['cnp_login'] = $this->config->get('cnp_login');
		}
		if (isset($this->request->post['cnp_login_euro'])) {
			$this->data['cnp_login_euro'] = $this->request->post['cnp_login_euro'];
		} else {
			$this->data['cnp_login_euro'] = $this->config->get('cnp_login_euro');
		}
		if (isset($this->request->post['cnp_login_pound'])) {
			$this->data['cnp_login_pound'] = $this->request->post['cnp_login_pound'];
		} else {
			$this->data['cnp_login_pound'] = $this->config->get('cnp_login_pound');
		}
		
		if (isset($this->request->post['cnp_key'])) {
			$this->data['cnp_key'] = $this->request->post['cnp_key'];
		} else {
			$this->data['cnp_key'] = $this->config->get('cnp_key');
		}
		
		if (isset($this->request->post['cnp_key_euro'])) {
			$this->data['cnp_key_euro'] = $this->request->post['cnp_key_euro'];
		} else {
			$this->data['cnp_key_euro'] = $this->config->get('cnp_key_euro');
		}
		
		if (isset($this->request->post['cnp_key_pound'])) {
			$this->data['cnp_key_pound'] = $this->request->post['cnp_key_pound'];
		} else {
			$this->data['cnp_key_pound'] = $this->config->get('cnp_key_pound');
		}
		
		if (isset($this->request->post['cnp_server'])) {
			$this->data['cnp_server'] = $this->request->post['cnp_server'];
		} else {
			$this->data['cnp_server'] = $this->config->get('cnp_server');
		}
		
		if (isset($this->request->post['cnp_server_pound'])) {
			$this->data['cnp_server_pound'] = $this->request->post['cnp_server_pound'];
		} else {
			$this->data['cnp_server_pound'] = $this->config->get('cnp_server_pound');
		}
		
		if (isset($this->request->post['cnp_server_euro'])) {
			$this->data['cnp_server_euro'] = $this->request->post['cnp_server_euro'];
		} else {
			$this->data['cnp_server_euro'] = $this->config->get('cnp_server_euro');
		}
		
		if (isset($this->request->post['cnp_status'])) {
			$this->data['cnp_status'] = $this->request->post['cnp_status'];
		} else {
			$this->data['cnp_status'] = $this->config->get('cnp_status');
		}
		
		if (isset($this->request->post['cnp_status_euro'])) {
			$this->data['cnp_status_euro'] = $this->request->post['cnp_status_euro'];
		} else {
			$this->data['cnp_status_euro'] = $this->config->get('cnp_status_euro');
		}
		if (isset($this->request->post['cnp_status_pound'])) {
			$this->data['cnp_status_pound'] = $this->request->post['cnp_status_pound'];
		} else {
			$this->data['cnp_status_pound'] = $this->config->get('cnp_status_pound');
		}
		
		if (isset($this->request->post['cnp_sort_order'])) {
			$this->data['cnp_sort_order'] = $this->request->post['cnp_sort_order'];
		} else {
			$this->data['cnp_sort_order'] = $this->config->get('cnp_sort_order');
		}
		
		//Other setting
		if (isset($this->request->post['clickandpledge_org_info'])) {
			$this->data['clickandpledge_org_info'] = $this->request->post['clickandpledge_org_info'];
		} else {
			$this->data['clickandpledge_org_info'] = $this->config->get('clickandpledge_org_info');
		}
		
		if (isset($this->request->post['clickandpledge_thank_you'])) {
			$this->data['clickandpledge_thank_you'] = $this->request->post['clickandpledge_thank_you'];
		} else {
			$this->data['clickandpledge_thank_you'] = $this->config->get('clickandpledge_thank_you');
		}
		
		if (isset($this->request->post['clickandpledge_terms_conditions'])) {
			$this->data['clickandpledge_terms_conditions'] = $this->request->post['clickandpledge_terms_conditions'];
		} else {
			$this->data['clickandpledge_terms_conditions'] = $this->config->get('clickandpledge_terms_conditions');
		}
		
		if (isset($this->request->post['clickandpledge_send_receipt'])) {
			$this->data['clickandpledge_send_receipt'] = $this->request->post['clickandpledge_send_receipt'];
		} else {
			$this->data['clickandpledge_send_receipt'] = $this->config->get('clickandpledge_send_receipt');
		}
		
		//install
		if (isset($this->request->post['install'])) {
			$this->data['install'] = $this->request->post['install'];
		} else {
			$this->data['install'] = $this->config->get('install');
		}
		
		if (isset($this->request->post['clickandpledge_creditcard'])) {
			$this->data['clickandpledge_creditcard'] = $this->request->post['clickandpledge_creditcard'];
		} else {
			$this->data['clickandpledge_creditcard'] = $this->config->get('clickandpledge_creditcard');
		}
		
		if (isset($this->request->post['clickandpledge_check'])) {
			$this->data['clickandpledge_check'] = $this->request->post['clickandpledge_check'];
		} else {
			$this->data['clickandpledge_check'] = $this->config->get('clickandpledge_check');
		}

		if (isset($this->request->post['clickandpledge_invoice'])) {
			$this->data['clickandpledge_invoice'] = $this->request->post['clickandpledge_invoice'];
		} else {
			$this->data['clickandpledge_invoice'] = $this->config->get('clickandpledge_invoice');
		}

		if (isset($this->request->post['clickandpledge_purchas_order'])) {
			$this->data['clickandpledge_purchas_order'] = $this->request->post['clickandpledge_purchas_order'];
		} else {
			$this->data['clickandpledge_purchas_order'] = $this->config->get('clickandpledge_purchas_order');
		}
		
		if (isset($this->request->post['payment_method_defaults'])) {
			$this->data['payment_method_defaults'] = $this->request->post['payment_method_defaults'];
		} else {
			$this->data['payment_method_defaults'] = $this->config->get('payment_method_defaults');
		}
		
		if (isset($this->request->post['clickandpledge_recurring_contribution'])) {
			$this->data['clickandpledge_recurring_contribution'] = $this->request->post['clickandpledge_recurring_contribution'];
		} else {
			$this->data['clickandpledge_recurring_contribution'] = $this->config->get('clickandpledge_recurring_contribution');
		}

		if (isset($this->request->post['clickandpledge_week'])) {
			$this->data['clickandpledge_week'] = $this->request->post['clickandpledge_week'];
		} else {
			$this->data['clickandpledge_week'] = $this->config->get('clickandpledge_week');
		}
		
		if (isset($this->request->post['clickandpledge_2_weeks'])) {
			$this->data['clickandpledge_2_weeks'] = $this->request->post['clickandpledge_2_weeks'];
		} else {
			$this->data['clickandpledge_2_weeks'] = $this->config->get('clickandpledge_2_weeks');
		}
	
		if (isset($this->request->post['clickandpledge_month'])) {
			$this->data['clickandpledge_month'] = $this->request->post['clickandpledge_month'];
		} else {
			$this->data['clickandpledge_month'] = $this->config->get('clickandpledge_month');
		}

		if (isset($this->request->post['clickandpledge_2_months'])) {
			$this->data['clickandpledge_2_months'] = $this->request->post['clickandpledge_2_months'];
		} else {
			$this->data['clickandpledge_2_months'] = $this->config->get('clickandpledge_2_months');
		}
		
		if (isset($this->request->post['clickandpledge_quarter'])) {
			$this->data['clickandpledge_quarter'] = $this->request->post['clickandpledge_quarter'];
		} else {
			$this->data['clickandpledge_quarter'] = $this->config->get('clickandpledge_quarter');
		}
		
		if (isset($this->request->post['clickandpledge_6_months'])) {
			$this->data['clickandpledge_6_months'] = $this->request->post['clickandpledge_6_months'];
		} else {
			$this->data['clickandpledge_6_months'] = $this->config->get('clickandpledge_6_months');
		}

		if (isset($this->request->post['clickandpledge_year'])) {
			$this->data['clickandpledge_year'] = $this->request->post['clickandpledge_year'];
		} else {
			$this->data['clickandpledge_year'] = $this->config->get('clickandpledge_year');
		}
		
		if (isset($this->request->post['clickandpledge_installment'])) {
			$this->data['clickandpledge_installment'] = $this->request->post['clickandpledge_installment'];
		} else {
			$this->data['clickandpledge_installment'] = $this->config->get('clickandpledge_installment');
		}
		
		if (isset($this->request->post['clickandpledge_subscription'])) {
			$this->data['clickandpledge_subscription'] = $this->request->post['clickandpledge_subscription'];
		} else {
			$this->data['clickandpledge_subscription'] = $this->config->get('clickandpledge_subscription');
		}
		
		if (isset($this->request->post['clickandpledge_indefinite'])) {
			$this->data['clickandpledge_indefinite'] = $this->request->post['clickandpledge_indefinite'];
		} else {
			$this->data['clickandpledge_indefinite'] = $this->config->get('clickandpledge_indefinite');
		}
		
		
		$this->template = 'payment/cnp.tpl';
		$this->children = array(
			'common/header',	
			'common/footer'	
		);
		$this->response->setOutput($this->render());		
    }
	 private function validate() {
		if (!$this->user->hasPermission('modify', 'payment/cnp')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!$this->request->post['cnp_login'] && !$this->request->post['cnp_login_euro'] && !$this->request->post['cnp_login_pound']) {
			$this->error['login'] = $this->language->get('error_login');
		}

		if (!$this->request->post['cnp_key'] && !$this->request->post['cnp_key_euro'] && !$this->request->post['cnp_key_pound']) {
			$this->error['key'] = $this->language->get('error_key');
		}
		
		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}	
	}
}
?>