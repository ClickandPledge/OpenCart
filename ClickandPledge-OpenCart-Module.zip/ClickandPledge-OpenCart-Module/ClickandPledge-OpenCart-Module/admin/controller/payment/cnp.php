<?php
class ControllerPaymentCnP extends Controller{

     private $error = array(); 

     public function index() {
		$this->load->language('payment/cnp');
		
		//$this->document->title = $this->language->get('heading_title');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {			
			$this->model_setting_setting->editSetting('cnp', $this->request->post);				
			
			$this->session->data['success'] = $this->language->get('text_success');

			$this->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
		}
        
		$this->data['heading_title'] = $this->language->get('heading_title');
		$this->data['text_enabled'] = $this->language->get('text_enabled');
		$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_all_zones'] = $this->language->get('text_all_zones');
		$this->data['text_yes'] = $this->language->get('text_yes');
		$this->data['text_no'] = $this->language->get('text_no');
		$this->data['text_live'] = $this->language->get('text_live');
		$this->data['text_test'] = $this->language->get('text_test');
		
		$this->data['entry_login'] = $this->language->get('entry_login');
		$this->data['entry_key'] = $this->language->get('entry_key');
		$this->data['entry_mode'] = $this->language->get('entry_mode');
		$this->data['entry_status'] = $this->language->get('entry_status');
		$this->data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');
		
		$this->data['tab_general'] = $this->language->get('tab_general');
		
		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}
		
		if (isset($this->error['login'])) {
			$this->data['error_login'] = $this->error['login'];
		} else {
			$this->data['error_login'] = '';
		}
		
		if (isset($this->error['key'])) {
			$this->data['error_key'] = $this->error['key'];
		} else {
			$this->data['error_key'] = '';
		}
		
		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('payment/cnp', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
		$this->data['action'] = $this->url->link('payment/cnp', 'token=' . $this->session->data['token'], 'SSL');
		
		$this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');
		
		if (isset($this->request->post['cnp_login'])) {
			$this->data['cnp_login'] = $this->request->post['cnp_login'];
		} else {
			$this->data['cnp_login'] = $this->config->get('cnp_login');
		}
		if (isset($this->request->post['cnp_login_euro'])) {
			$this->data['cnp_login_euro'] = $this->request->post['cnp_login_euro'];
		} else {
			$this->data['cnp_login_euro'] = $this->config->get('cnp_login_euro');
		}
		if (isset($this->request->post['cnp_login_pound'])) {
			$this->data['cnp_login_pound'] = $this->request->post['cnp_login_pound'];
		} else {
			$this->data['cnp_login_pound'] = $this->config->get('cnp_login_pound');
		}
		
		if (isset($this->request->post['cnp_key'])) {
			$this->data['cnp_key'] = $this->request->post['cnp_key'];
		} else {
			$this->data['cnp_key'] = $this->config->get('cnp_key');
		}
		
		if (isset($this->request->post['cnp_key_euro'])) {
			$this->data['cnp_key_euro'] = $this->request->post['cnp_key_euro'];
		} else {
			$this->data['cnp_key_euro'] = $this->config->get('cnp_key_euro');
		}
		
		if (isset($this->request->post['cnp_key_pound'])) {
			$this->data['cnp_key_pound'] = $this->request->post['cnp_key_pound'];
		} else {
			$this->data['cnp_key_pound'] = $this->config->get('cnp_key_pound');
		}
		
		if (isset($this->request->post['cnp_server'])) {
			$this->data['cnp_server'] = $this->request->post['cnp_server'];
		} else {
			$this->data['cnp_server'] = $this->config->get('cnp_server');
		}
		
		if (isset($this->request->post['cnp_server_pound'])) {
			$this->data['cnp_server_pound'] = $this->request->post['cnp_server_pound'];
		} else {
			$this->data['cnp_server_pound'] = $this->config->get('cnp_server_pound');
		}
		
		if (isset($this->request->post['cnp_server_euro'])) {
			$this->data['cnp_server_euro'] = $this->request->post['cnp_server_euro'];
		} else {
			$this->data['cnp_server_euro'] = $this->config->get('cnp_server_euro');
		}
		
		if (isset($this->request->post['cnp_status'])) {
			$this->data['cnp_status'] = $this->request->post['cnp_status'];
		} else {
			$this->data['cnp_status'] = $this->config->get('cnp_status');
		}
		
		if (isset($this->request->post['cnp_status_euro'])) {
			$this->data['cnp_status_euro'] = $this->request->post['cnp_status_euro'];
		} else {
			$this->data['cnp_status_euro'] = $this->config->get('cnp_status_euro');
		}
		if (isset($this->request->post['cnp_status_pound'])) {
			$this->data['cnp_status_pound'] = $this->request->post['cnp_status_pound'];
		} else {
			$this->data['cnp_status_pound'] = $this->config->get('cnp_status_pound');
		}
		
		if (isset($this->request->post['cnp_sort_order'])) {
			$this->data['cnp_sort_order'] = $this->request->post['cnp_sort_order'];
		} else {
			$this->data['cnp_sort_order'] = $this->config->get('cnp_sort_order');
		}
		
		$this->template = 'payment/cnp.tpl';
		$this->children = array(
			'common/header',	
			'common/footer'	
		);
		$this->response->setOutput($this->render());		
    }
	 private function validate() {
		if (!$this->user->hasPermission('modify', 'payment/cnp')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!$this->request->post['cnp_login'] && !$this->request->post['cnp_login_euro'] && !$this->request->post['cnp_login_pound']) {
			$this->error['login'] = $this->language->get('error_login');
		}

		if (!$this->request->post['cnp_key'] && !$this->request->post['cnp_key_euro'] && !$this->request->post['cnp_key_pound']) {
			$this->error['key'] = $this->language->get('error_key');
		}
		
		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}	
	}
}
?>