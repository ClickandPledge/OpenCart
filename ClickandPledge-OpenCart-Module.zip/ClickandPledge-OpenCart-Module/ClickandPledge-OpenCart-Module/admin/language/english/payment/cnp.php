<?php
// Heading
$_['heading_title']      = 'Click & Pledge';

// Text 
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Click & Pledge account details!';
$_['text_cnp']      = '<a onclick="window.open(\'https://www.clickandpledge.com\');"><img src="view/image/payment/cnp.png" alt="clickandpledge" title="clickandpledge" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_test']          = 'Test';
$_['text_live']          = 'Production';

// Entry
$_['entry_login']        = 'Account ID:';
$_['entry_key']          = 'API Account GUID:';
$_['entry_mode']         = 'Transaction Mode:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';

// Error 
$_['error_permission']   = 'Warning: You do not have permission to modify payment Click & Pledge!';
$_['error_login']        = 'Account ID Required!';
$_['error_key']          = 'API Account GUID Required!';

?>