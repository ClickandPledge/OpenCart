<?php
// Text
$_['text_title']           = 'Click & Pledge';
$_['text_credit_card']     = 'Credit Card Details';
$_['text_wait']            = 'Please wait!';

// Entry
$_['entry_cc_owner']       = 'Name on Card';
$_['entry_cc_number']      = 'Credit Card Number';
$_['entry_cc_expire_date'] = 'Expiration Date';
$_['entry_cc_cvv2']        = 'Card Verification (CVV)';
?>