<?php

class ModelExtensionPaymentCnP extends Model {

	public function install() {
	
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cnpsettingsinfo` (
			  `cnpsettingsinfo_id` int(11) NOT NULL AUTO_INCREMENT,
			  `cnpsettingsinfo_clientid` varchar(255) COLLATE utf8_bin NOT NULL,
			  `cnpsettingsinfo_clentsecret` varchar(255) COLLATE utf8_bin NOT NULL,
			  `cnpsettingsinfo_granttype` varchar(255) COLLATE utf8_bin NOT NULL,
			  `cnpsettingsinfo_scope` varchar(255) COLLATE utf8_bin NOT NULL,
			   PRIMARY KEY (`cnpsettingsinfo_id`)
			)");

			$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cnptokeninfo` (
			  `cnptokeninfo_id` int(11) NOT NULL AUTO_INCREMENT,
			  `cnptokeninfo_username` varchar(255) COLLATE utf8_bin NOT NULL,
			  `cnptokeninfo_code` varchar(255) COLLATE utf8_bin NOT NULL,
			  `cnptokeninfo_accesstoken` text COLLATE utf8_bin NOT NULL,
			  `cnptokeninfo_refreshtoken` text COLLATE utf8_bin NOT NULL,
			  `cnptokeninfo_date_added` datetime NOT NULL,
			  `cnptokeninfo_date_modified` datetime NOT NULL,
			  PRIMARY KEY (`cnptokeninfo_id`)
			)");

		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cnpaccountsinfo` (
			  `cnpaccountsinfo_id` int(11) NOT NULL AUTO_INCREMENT,
			  `cnpaccountsinfo_orgid` varchar(100) NOT NULL,
  			  `cnpaccountsinfo_orgname` varchar(250) NOT NULL,
  	          `cnpaccountsinfo_accountguid` varchar(250) NOT NULL,
			  `cnpaccountsinfo_userfirstname` varchar(250) NOT NULL,
			  `cnpaccountsinfo_userlastname` varchar(250) NOT NULL,
			  `cnpaccountsinfo_userid` varchar(250) NOT NULL,
			  `cnpaccountsinfo_crtdon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  `cnpaccountsinfo_crtdby` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  PRIMARY KEY (`cnpaccountsinfo_id`)
			)");
		$this->db->query("INSERT INTO " . DB_PREFIX . "cnpsettingsinfo (`cnpsettingsinfo_id`, `cnpsettingsinfo_clientid`, `cnpsettingsinfo_clentsecret`, `cnpsettingsinfo_granttype`, `cnpsettingsinfo_scope`) VALUES (NULL, 'connectwordpressplugin', 'zh6zoyYXzsyK9fjVQGd8m+ap4o1qP2rs5w/CO2fZngqYjidqZ0Fhbhi1zc/SJ5zl', 'password', 'openid profile offline_access')");
	}
    public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cnpsettingsinfo`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cnptokeninfo`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cnpaccountsinfo`;");
	}
	public function getCnPsettingsinfo($cnpemail,$cnpcode) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnpsettingsinfo");

		if ($query->num_rows) {
			$password="password";
			$cnpsecret = openssl_decrypt($query->row['cnpsettingsinfo_clentsecret'],"AES-128-ECB",$password);
			$data = "client_id=".$query->row['cnpsettingsinfo_clientid']."&client_secret=". $cnpsecret."&grant_type=".$query->row['cnpsettingsinfo_granttype']."&scope=".$query->row['cnpsettingsinfo_scope']."&username=".$cnpemail."&password=".$cnpcode;
			return $data;
			exit;
		} else {
			return 0;
		}
	}
	public function CnPTokeninfo($cnpemail,$cnpcode,$cnptoken,$cnprtoken)
	{
		
		$cnpresult = $this->db->query("INSERT INTO " . DB_PREFIX . "cnptokeninfo (`cnptokeninfo_id`, `cnptokeninfo_username`, `cnptokeninfo_code`, `cnptokeninfo_accesstoken`, `cnptokeninfo_refreshtoken`) VALUES (NULL,'$cnpemail', '$cnpcode', '$cnptoken','$cnprtoken')");
		return $cnpresult;
	}
	public function CnPAccountList($cnporgid,$cnporgname,$cnpaccountid,$cnpufname,$cnplname,$cnpuid)
	{		
		$cnpresult =$this->db->query("INSERT INTO " . DB_PREFIX . "cnpaccountsinfo (`cnpaccountsinfo_orgid`, `cnpaccountsinfo_orgname`, `cnpaccountsinfo_accountguid`, `cnpaccountsinfo_userfirstname`, `cnpaccountsinfo_userlastname`,`cnpaccountsinfo_userid`) VALUES ('$cnporgid', '$cnporgname', '$cnpaccountid', '$cnpufname','$cnplname','$cnpuid')");
		return $cnpresult;
	}
	public function getCnPAccountNumrows() {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnpaccountsinfo");
			return $query->num_rows;
		
	}
	public function CnPAccountDeleteList() {
		$query = $this->db->query("DELETE from " . DB_PREFIX . "cnpaccountsinfo");
		//	return $query->num_rows;
	}
	public function CnPtokenDeleteList() {
		$query = $this->db->query("DELETE from " . DB_PREFIX . "cnptokeninfo");
			return $query;
	}
	public function getCnPrefreshtoken() {
		$query = $this->db->query("SELECT cnptokeninfo_refreshtoken  FROM " . DB_PREFIX . "cnptokeninfo");
		$cnprefreshtkn = $query->row['cnptokeninfo_refreshtoken'];
		
		$cnpsettingsquery = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnpsettingsinfo");

		if ($cnpsettingsquery->num_rows) {
			$password="password";
			$cnpsecret = openssl_decrypt($cnpsettingsquery->row['cnpsettingsinfo_clentsecret'],"AES-128-ECB",$password);
		
			$data = "client_id=".$cnpsettingsquery->row['cnpsettingsinfo_clientid']."&client_secret=". $cnpsecret."&grant_type=refresh_token&scope=".$cnpsettingsquery->row['cnpsettingsinfo_scope']."&refresh_token=".$cnprefreshtkn;
				
			return $data;
			exit;
		} else {
			return 0;
		}
			
		
	}
	 public function getCnPUser() {
		$cnpAccountId ="";
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnpaccountsinfo");
		if ($query->num_rows) {
			foreach ($query->rows as $result) {
			$cnpAccountId      = $result['cnpaccountsinfo_userid'];
			}
		 }
	 return $cnpAccountId;
		
	}
	 public function getCnPAccountGUID($accid) {
		$cnpAccountGUId ="";
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnpaccountsinfo where cnpaccountsinfo_orgid ='".$accid."'");
		if ($query->num_rows) {
			foreach ($query->rows as $result) {
			
			$cnpAccountGUId      = $result['cnpaccountsinfo_accountguid'];
			}
		 }
	 return $cnpAccountGUId;
		
	}
			
  public function getMCnPUserEmailAccountList($email) {
		$cnprtrntxt = $this->getCnPactiveCampaigns($email);
	    $cnprtrnpaymentstxt = $this->getCnPactivePaymentsList($email);
	  return $cnprtrntxt."||".$cnprtrnpaymentstxt;
	}
	public function getCnPAccountsList() {
		$data['cnpaccounts'] = array();
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnpaccountsinfo");
		
		if ($query->num_rows) {
			foreach ($query->rows as $result) {
			$data['cnpaccounts'][] = array(
       		'AccountId'      => $result['cnpaccountsinfo_orgid'],
			'GUID'           => $result['cnpaccountsinfo_accountguid'],
			'Organization'           => $result['cnpaccountsinfo_orgname']    
   		);
			}
		 }return $data['cnpaccounts'];
		
	}
	
	public function getCnPactivePaymentsList($cnpaccid)
	{
		$cmpacntacptdcards ="";
		$cnpacountid = $cnpaccid;
		$cnpaccountGUID = $this->getCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect1  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client1   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect1);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr1  = new SimpleXMLElement("<GetAccountDetail></GetAccountDetail>");
			$xmlr1->addChild('accountId',$cnpacountid);
			$xmlr1->addChild('accountGUID',$cnpaccountGUID);
			$xmlr1->addChild('username',$cnpUID);
			$xmlr1->addChild('password',$cnpKey);
			$response1                    = $client1->GetAccountDetail($xmlr1);
			$responsearramex              =  $response1->GetAccountDetailResult->Amex;
			$responsearrJcb               =  $response1->GetAccountDetailResult->Jcb;
			$responsearrMaster            =  $response1->GetAccountDetailResult->Master;
			$responsearrVisa              =  $response1->GetAccountDetailResult->Visa;
			$responsearrDiscover          =  $response1->GetAccountDetailResult->Discover;
			$responsearrecheck            =  $response1->GetAccountDetailResult->Ach;
			$responsearrCustomPaymentType =  $response1->GetAccountDetailResult->CustomPaymentType;
			$cnpamex 					  =  $this->config->get('payment_cnp_hidcnpamex');
			$cnpjcb 					  =  $this->config->get('payment_cnp_hidcnpjcb');
			$cnpMaster 					  =  $this->config->get('payment_cnp_hidcnpMaster');
			$cnpVisa 					  =  $this->config->get('payment_cnp_hidcnpVisa');
			$cnpDiscover 				  =  $this->config->get('payment_cnp_hidcnpDiscover');
				$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpcreditcard" id="payment_cnp_hidcnpcreditcard"';
			if($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true ){ 
				$cmpacntacptdcards .= ' value="CreditCard">';
			}
			else{ $cmpacntacptdcards .= ' value="">'; }
				$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpeCheck" id="payment_cnp_hidcnpeCheck"';
			if($responsearrecheck == true){
				$cmpacntacptdcards .= ' value="eCheck">';
			}else{ $cmpacntacptdcards .= ' value="">'; }
			if($responsearramex == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpamex" id="payment_cnp_hidcnpamex" value="amex">';
			}
			if($responsearrJcb == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpjcb" id="payment_cnp_hidcnpjcb" value="jcb">';
			}
			if($responsearrMaster == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpMaster" id="payment_cnp_hidcnpMaster" value="Master">';
			}
			if($responsearrVisa == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpVisa" id="payment_cnp_hidcnpVisa" value="Visa">';
			}
			if($responsearrDiscover == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpDiscover" id="payment_cnp_hidcnpDiscover" value="Discover">';
			}
			$cmpacntacptdcards .= '<table cellpadding="5" cellspacing="3" style="font-weight:bold;padding:2px;" id="tblacceptedcards">
                    <tbody><tr>
					
                    <td width="200"><input type="checkbox" id="payment_cnp_creditcard" class="checkbox_active" value="CreditCard" name="payment_cnp_creditcard"  onclick="block_creditcard(this.checked);" ';
			if($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true ){ $cmpacntacptdcards .= 'checked="checked"';}
		     $cmpacntacptdcards .= ' checked="checked" disabled="disabled"> Credit Card</td></tr>
			 <tr class="tracceptedcards"><td></td><td>
			 <table cellspacing="0">
					
					<tbody class="accounts">
						<tr class="account">								
									<td style="padding:2px;"><strong>Accepted Credit Cards</strong></td></tr>';
								if($responsearrVisa == true){
									
							      $cmpacntacptdcards .= '<tr class="account">								
									<td style="padding:2px;"><br><input type="Checkbox" name="payment_cnp_Visa" id="payment_cnp_Visa" checked="checked" value="Visa" disabled="disabled">Visa</td></tr>';
								}if($responsearramex == true){
									$cmpacntacptdcards .= '<tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_American_Express" id="payment_cnp_American_Express" checked="checked"  disabled="disabled" value="American Express">American Express</td>
								  </tr>';
								}if($responsearrDiscover == true){
								 $cmpacntacptdcards .= ' <tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_Discover" id="payment_cnp_Discover" checked="checked" value="Discover" disabled="disabled">Discover</td>
								  </tr>';
								}if($responsearrMaster == true){
								  $cmpacntacptdcards .= '<tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_MasterCard" id="payment_cnp_MasterCard" checked="checked" value="MasterCard" disabled="disabled">MasterCard</td>
								  </tr>';
								}if($responsearrJcb == true){
								  $cmpacntacptdcards .= '<tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_JCB" id="payment_cnp_JCB" checked="checked" value="JCB" disabled="disabled">JCB</td>
								  </tr>';
								}
			$cmpacntacptdcards .= '</tbody></table></td></tr>';
			if($responsearrecheck == true){
			$cmpacntacptdcards .='<tr><td><input type="checkbox" value="eCheck" id="payment_cnp_check" class="checkbox_active" name="payment_cnp_check" onclick="block_echek(this.checked);" checked="checked" disabled="disabled"> eCheck</td></tr>';
			}
			if($responsearrCustomPaymentType == true){
			$cmpacntacptdcards .='<tr><td><input type="checkbox" value="Purchase Order" id="payment_cnp_purchas_order" class="checkbox_active" name="payment_cnp_purchas_order" onclick="block_custom(this.checked);" checked="checked"> Custom Payment</td></tr>';
			}
					$cmpacntacptdcards .= '</tbody></table>';

		}	
		
		return $cmpacntacptdcards;
	}
	public function getCnPactivePaymentList($cnpaccid)
	{
		$cmpacntacptdcards = "";
		$cnpacountid = $cnpaccid;
		$cnpaccountGUID = $this->getCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect1  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client1   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect1);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr1  = new SimpleXMLElement("<GetAccountDetail></GetAccountDetail>");
			$xmlr1->addChild('accountId',$cnpacountid);
			$xmlr1->addChild('accountGUID',$cnpaccountGUID);
			$xmlr1->addChild('username',$cnpUID);
			$xmlr1->addChild('password',$cnpKey);
			$response1                    = $client1->GetAccountDetail($xmlr1);
			$responsearramex              =  $response1->GetAccountDetailResult->Amex;
			$responsearrJcb               =  $response1->GetAccountDetailResult->Jcb;
			$responsearrMaster            =  $response1->GetAccountDetailResult->Master;
			$responsearrVisa              =  $response1->GetAccountDetailResult->Visa;
			$responsearrDiscover          =  $response1->GetAccountDetailResult->Discover;
			$responsearrecheck            =  $response1->GetAccountDetailResult->Ach;
			$responsearrCustomPaymentType =  $response1->GetAccountDetailResult->CustomPaymentType;
			$cnpamex 					  =  $this->config->get('payment_cnp_hidcnpamex');
			$cnpjcb 					  =  $this->config->get('payment_cnp_hidcnpjcb');
			$cnpMaster 					  =  $this->config->get('payment_cnp_hidcnpMaster');
			$cnpVisa 					  =  $this->config->get('payment_cnp_hidcnpVisa');
			$cnpDiscover 				  =  $this->config->get('payment_cnp_hidcnpDiscover');
			$cnpecheck 				      =  $this->config->get('payment_cnp_check');
			$cnpcp 				          =  $this->config->get('payment_cnp_purchas_order');
			$cnpcc 				          =  $this->config->get('payment_cnp_creditcard');
				$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpcreditcard" id="payment_cnp_hidcnpcreditcard"';
			if($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true ){ 
				$cmpacntacptdcards .= ' value="CreditCard">';
			}else{ $cmpacntacptdcards .= ' value="">'; }
				$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpeCheck" id="payment_cnp_hidcnpeCheck"';
			if($responsearrecheck == true){
				$cmpacntacptdcards .= ' value="eCheck">';
			}else{ $cmpacntacptdcards .= ' value="">'; }
			if($responsearramex == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpamex" id="payment_cnp_hidcnpamex" value="amex">';
			}
			if($responsearrJcb == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpjcb" id="payment_cnp_hidcnpjcb" value="jcb">';
			}
			if($responsearrMaster == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpMaster" id="payment_cnp_hidcnpMaster" value="Master">';
			}
			if($responsearrVisa == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpVisa" id="payment_cnp_hidcnpVisa" value="Visa">';
			}
			if($responsearrDiscover == true){
			$cmpacntacptdcards .= '<input type="hidden" name="payment_cnp_hidcnpDiscover" id="payment_cnp_hidcnpDiscover" value="Discover">';
			}
			$cmpacntacptdcards .= '<table cellpadding="5" cellspacing="3" style="font-weight:bold;padding:2px;" id="tblacceptedcards">
                    <tbody><tr>
                    <td width="200"><input type="checkbox" id="payment_cnp_creditcard" class="checkbox_active" value="CreditCard" name="payment_cnp_creditcard"  onclick="block_creditcard(this.checked);" ';
			if(($responsearramex == true || $responsearrJcb == true || $responsearrMaster== true || $responsearrVisa ==true || $responsearrDiscover == true) )
			{$cmpacntacptdcards .= 'checked="checked"';}
		     $cmpacntacptdcards .= 'checked="checked" disabled="disabled"> Credit Card</td></tr>
			 <tr class="tracceptedcards"><td></td><td>
			 <table cellspacing="0">
					
					<tbody class="accounts">
						<tr class="account">								
									<td style="padding:2px;"><strong>Accepted Credit Cards</strong></td></tr>';
								if($responsearrVisa == true){
									
							      $cmpacntacptdcards .= '<tr class="account">								
									<td style="padding:2px;"><br><input type="Checkbox" name="payment_cnp_Visa" id="payment_cnp_Visa"';
									if(isset($cnpVisa)){ $cmpacntacptdcards .='checked="checked "'; }
									 $cmpacntacptdcards .= 'value="Visa" checked="checked" disabled="disabled">Visa</td></tr>';
								  }
								if($responsearramex == true){
									$cmpacntacptdcards .= '<tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_American_Express" id="payment_cnp_American_Express"';
									if(isset($cnpamex)){ $cmpacntacptdcards .='checked="checked"'; }
									$cmpacntacptdcards .= 'value="American Express" checked="checked" disabled="disabled">American Express</td>
								  </tr>';
								}if($responsearrDiscover == true){
								 $cmpacntacptdcards .= ' <tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_Discover" id="payment_cnp_Discover"'; 
									if(isset($cnpDiscover)){ $cmpacntacptdcards .='checked="checked"'; }
										$cmpacntacptdcards .= ' value="Discover" checked="checked" disabled="disabled">Discover</td>
								  </tr>';
								}if($responsearrMaster == true){
								  $cmpacntacptdcards .= '<tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_MasterCard" id="payment_cnp_MasterCard"';
									if(isset($cnpMaster)){ $cmpacntacptdcards .='checked="checked"'; }
									$cmpacntacptdcards .= ' value="MasterCard"  checked="checked" disabled="disabled">MasterCard</td>
								  </tr>';
								}if($responsearrJcb == true){
								  $cmpacntacptdcards .= '<tr>
									<td style="padding:2px;"><input type="Checkbox" name="payment_cnp_JCB" id="payment_cnp_JCB"';
									if(isset($cnpjcb)){ $cmpacntacptdcards .='checked="checked"'; }
									$cmpacntacptdcards .= ' value="JCB" checked="checked" disabled="disabled">JCB</td>
								  </tr>';
								}
			$cmpacntacptdcards .= '</tbody></table></td></tr>';
			if($responsearrecheck == true){
			$cmpacntacptdcards .='<tr><td><input type="checkbox" value="eCheck" id="payment_cnp_check" class="checkbox_active" name="payment_cnp_check" onclick="block_echek(this.checked);"';
				if(isset($cnpecheck)){ $cmpacntacptdcards .='checked="checked"'; }
				 $cmpacntacptdcards .= ' checked="checked" disabled="disabled"> eCheck</td></tr>';
			}
			if($responsearrCustomPaymentType == true){
			$cmpacntacptdcards .='<tr><td><input type="checkbox" value="Purchase Order" id="payment_cnp_purchas_order" class="checkbox_active" name="payment_cnp_purchas_order" onclick="block_custom(this.checked);"'; if(isset($cnpcp)){ $cmpacntacptdcards .='checked="checked"'; }
				 $cmpacntacptdcards .= '> Custom Payment</td></tr>';
			}
					$cmpacntacptdcards .= '</tbody></table>';

		}	
		
		return $cmpacntacptdcards;
	}
	public function in_array_r($needle, $haystack, $strict = false) {
    foreach ($haystack as $item) {
        if (($strict ? $item === $needle : $item == $needle) || 
			(is_array($item) && in_array_r($needle, $item, $strict))) {
            return true;
        }
    }

    return false;
}
	public function getCnPactiveCampaigns($cnpaccid)
	{
		
		if($cnpaccid != ""){
			$cnpacountid = $cnpaccid;
		$cnpaccountGUID = $this->getCnPAccountGUID($cnpacountid);
		$cnpUID = "14059359-D8E8-41C3-B628-E7E030537905";
		$cnpKey = "5DC1B75A-7EFA-4C01-BDCD-E02C536313A3";
		$connect  = array('soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0);
	    $client   = new SoapClient('https://resources.connect.clickandpledge.com/wordpress/Auth2.wsdl', $connect);
		if( isset($cnpacountid) && $cnpacountid !="" && isset($cnpaccountGUID) &&  $cnpaccountGUID !="")
		{ 
			$xmlr  = new SimpleXMLElement("<GetActiveCampaignList2></GetActiveCampaignList2>");
			$cnpsel ="";
	$xmlr->addChild('accountId', $cnpacountid);
	$xmlr->addChild('AccountGUID', $cnpaccountGUID);
	$xmlr->addChild('username', $cnpUID);
	$xmlr->addChild('password', $cnpKey);
	$response = $client->GetActiveCampaignList2($xmlr); 
    $responsearr =  $response->GetActiveCampaignList2Result->connectCampaign;
	$cnpcampaignalias = $this->config->get('payment_cnp_connectcampaign_URLalias');
	
	 $camrtrnval = "<option value=''>Select Campaign Name</option>";
	 if(count($responsearr) == 1)
		{
			if($responsearr->alias == $cnpcampaignalias){ $cnpsel ="selected='selected'";}
		 $camrtrnval.= "<option value='".$responsearr->alias."' ".$cnpsel." >".$responsearr->name." ( ".$responsearr->alias." )</option>";
		}else{
			for($inc = 0 ; $inc < count($responsearr);$inc++)
			{ if($responsearr[$inc]->alias == $cnpcampaignalias){ $cnpsel ="selected='selected'";}else{$cnpsel ="";}
			 $camrtrnval .= "<option value='".$responsearr[$inc]->alias."' ".$cnpsel.">".$responsearr[$inc]->name." ( ".$responsearr[$inc]->alias." )</option>";
			}

		}	
		}
		return $camrtrnval;
		}
	}
	public function getCnPAccountsemailList() {
		$data['cnpaccountsnm'] = array();
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cnptokeninfo ORDER BY cnptokeninfo_id DESC");
		
		if ($query->num_rows) {
			foreach ($query->rows as $result) {
			$data['cnpaccountsnm'][] = array(
       		'AccountUsername'      => $result['cnptokeninfo_username']    
   		);
			}
		 }return $data['cnpaccountsnm'];
		
	}
}