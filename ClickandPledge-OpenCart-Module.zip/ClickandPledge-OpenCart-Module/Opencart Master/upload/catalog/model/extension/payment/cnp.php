<?php 
class ModelExtensionPaymentCnP extends Model {
  	public function getMethod($address, $total) {
		$this->load->language('extension/payment/cnp');
		$currency = $this->session->data['currency'];
		$taxes = $this->cart->getTaxes();
   		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('payment_cnp_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		if ($this->config->get('payment_cnp_checkout_total') > 0 && $this->config->get('payment_cnp_checkout_total') > $total) {
		 $status = FALSE;
			}elseif (!$this->config->get('payment_cnp_geo_zone_id')) {
        		$status = TRUE;
      		} elseif ($query->num_rows) {
      		  	$status = TRUE;
      		} else {
     	  		$status = FALSE;
			}	
  
		$method_data = array();

		if ($status) {  
      		$method_data = array( 
        		'code'         => 'cnp',
        		'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_cnp_sort_order')
      		);
    	}
    	return $method_data;
  	}
	 function getTaxesCnp() {
	
			 $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "tax_rate");

		 return $query->rows;
	 }
	 function getGUID($accountid) {
	
			 $query = $this->db->query("SELECT *  FROM " . DB_PREFIX . "cnpaccountsinfo WHERE cnpaccountsinfo_orgid ='".$accountid."'");

		 return $query->rows;
	 }
	 function getCnpTaxClassId() {
	
			 $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "tax_class");

		 return $query->rows;
	 }
	public function getMonths() {
		$months = array();

		for ($i = 1; $i <= 12; $i++) {
			$months[] = array(
				'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
				'value' => sprintf('%02d', $i)
			);
		}

		return $months;
	}

	public function getYears() {
		$years = array();

		$today = getdate();

		for ($i = $today['year']; $i <= $today['year'] + 20; $i++) {
			$years[] = array(
				'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
				'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
			);
		}

		return $years;
	}
}
?>