<?php
class ControllerExtensionPaymentCnP extends Controller{

    private $error = array(); 

     public function index() {
		//$this->install();
		$this->load->language('extension/payment/cnp');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		$this->load->model('extension/payment/cnp');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {
			$this->model_setting_setting->editSetting('payment_cnp', $this->request->post);	
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=payment', 'SSL'));
		}
		
       
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_all_zones'] = $this->language->get('text_all_zones');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_live'] = $this->language->get('text_live');
		$data['text_test'] = $this->language->get('text_test');
		
		$data['entry_login'] = $this->language->get('entry_login');
		$data['entry_key'] = $this->language->get('entry_key');
		$data['entry_mode'] = $this->language->get('entry_mode');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_method'] = $this->language->get('entry_method');
		$data['entry_total'] = $this->language->get('entry_total');
		$data['entry_total_help'] = $this->language->get('entry_total_help');
		
		//Other settings
		//$data['organization_information'] = $this->language->get('organization_information');
		$data['terms_conditions'] = $this->language->get('terms_conditions');
		$data['receipt_setting'] = $this->language->get('receipt_setting');
		$data['receipt_setting'] = $this->language->get('receipt_setting');
		$data['payment_methods'] = $this->language->get('payment_methods');
		$data['payment_method_default'] = $this->language->get('payment_method_default');
		
		//recurring contribuction
		$data['cnp_recurring_contribution'] = $this->language->get('cnp_recurring_contribution');

		$data['cnp_week'] = $this->language->get('cnp_week');
		$data['cnp_2_weeks'] = $this->language->get('cnp_2_weeks');
		$data['cnp_month'] = $this->language->get('cnp_month');
		$data['cnp_2_months'] = $this->language->get('cnp_2_months');
		$data['cnp_quarter'] = $this->language->get('cnp_quarter');
		$data['cnp_6_months'] = $this->language->get('cnp_6_months');
		$data['cnp_year'] = $this->language->get('cnp_year');
		
		$data['cnp_installment'] = $this->language->get('cnp_installment');
		$data['cnp_subscription'] = $this->language->get('cnp_subscription');
		$data['cnp_indefinite'] = $this->language->get('cnp_indefinite');
		
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		$data['tab_general'] = $this->language->get('tab_general');
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['login'])) {
			$data['error_login'] = $this->error['login'];
		} else {
			$data['error_login'] = '';
		}
		
		if (isset($this->error['key'])) {
			$data['error_key'] = $this->error['key'];
		} else {
			$data['error_key'] = '';
		}
		
		 $data['breadcrumbs']  = array();
		 $data['cnpacnts']     = array();
		 
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')      		
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'user_token=' . $this->session->data['user_token'], 'SSL')      		
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('extension/payment/cnp', 'user_token=' . $this->session->data['user_token'], 'SSL')      		
   		);
	   $data['cnpacnts'] = $this->model_extension_payment_cnp->getCnPAccountsList();
		
	   //$data['cnpacntsnm'] = $this->model_extension_payment_cnp->getCnPAccountsemailList();
	   $data['cnp_logged_user'] = $this->model_extension_payment_cnp->getCnPUser();
	   $cnpactuser = $this->config->get('payment_cnp_login');
		//print_r($data['cnpacnts']);
			foreach($data['cnpacnts'] as $v) {
			   if ($v['AccountId'] == $cnpactuser) {
				  $found = true;
				   $cnpactiveuser = $v['AccountId'];
			   }
			} 
		 if(!isset($found) && !empty($data['cnpacnts'])) {$cnpactiveuser = $data['cnpacnts'][0]['AccountId'];}
		/* if ($this->model_extension_payment_cnp->in_array_r($cnpactuser, $data['cnpacnts'])) {
			 
			 $cnpactiveuser = $this->config->get('payment_cnp_login'); echo $cnpactiveuser;
		 }else {

			 $cnpactiveuser = $data['cnpacnts'][0]['AccountId'];			 echo $cnpactiveuser;
		 }*/
		 if(isset($cnpactiveuser) && $cnpactiveuser!="")
		 {
		$data['cnp_activecampaings']=$this->model_extension_payment_cnp->getCnPactiveCampaigns($cnpactiveuser);
		$data['cnp_acceptedcards']=$this->model_extension_payment_cnp->getCnPactivePaymentList($cnpactiveuser);
			 }
		$data['action'] = $this->url->link('extension/payment/cnp', 'user_token=' . $this->session->data['user_token'], 'SSL');		
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', 'SSL');
		
		
		//USD
		if (isset($this->request->post['payment_cnp_login'])) {
			$data['payment_cnp_login'] = $this->request->post['payment_cnp_login'];
		} else {
			$data['payment_cnp_login'] = $this->config->get('payment_cnp_login');
		}
		
		if (isset($this->request->post['cnp_server'])) {
			$data['payment_cnp_server'] = $this->request->post['payment_cnp_server'];
		} else {
			$data['payment_cnp_server'] = $this->config->get('payment_cnp_server');
		}
		
		if (isset($this->request->post['payment_cnp_connectcampaign_URLalias'])) {
			$data['payment_cnp_connectcampaign_URLalias'] = $this->request->post['payment_cnp_connectcampaign_URLalias'];
		} else {
			$data['payment_cnp_connectcampaign_URLalias'] = $this->config->get('payment_cnp_connectcampaign_URLalias');
		}
		
	
		
		if (isset($this->request->post['payment_cnp_status'])) {
			$data['payment_cnp_status'] = $this->request->post['payment_cnp_status'];
		} else {
			$data['payment_cnp_status'] = $this->config->get('payment_cnp_status');
		}
		//Other setting

		if (isset($this->request->post['payment_cnp_sort_order'])) {
			$data['payment_cnp_sort_order'] = $this->request->post['payment_cnp_sort_order'];
		} else {
			$data['payment_cnp_sort_order'] = $this->config->get('payment_cnp_sort_order');
		}
		if (isset($this->request->post['payment_cnp_checkout_total'])) {
			$data['payment_cnp_checkout_total'] = $this->request->post['payment_cnp_checkout_total'];
		} else {
			$data['payment_cnp_checkout_total'] = $this->config->get('payment_cnp_checkout_total');
		}

		if (isset($this->request->post['payment_cnp_organization_information'])) {
			$data['payment_cnp_organization_information'] = $this->request->post['payment_cnp_organization_information'];
		} else {
			$data['payment_cnp_organization_information'] = $this->config->get('payment_cnp_organization_information');
		}
		 
		if (isset($this->request->post['payment_cnp_terms_conditions'])) {
			$data['payment_cnp_terms_conditions'] = $this->request->post['payment_cnp_terms_conditions'];
		} else {
			$data['payment_cnp_terms_conditions'] = $this->config->get('payment_cnp_terms_conditions');
		}
		
		if (isset($this->request->post['payment_cnp_send_receipt'])) {
			$data['payment_cnp_send_receipt'] = $this->request->post['payment_cnp_send_receipt'];
		} else {
			$data['payment_cnp_send_receipt'] = $this->config->get('payment_cnp_send_receipt');
		}
		
		//install
		if (isset($this->request->post['payment_cnp_install'])) {
			$data['payment_cnp_install'] = $this->request->post['payment_cnp_install'];
		} else {
			$data['payment_cnp_install'] = $this->config->get('payment_cnp_install');
		}
		
		if (isset($this->request->post['payment_cnp_hidcnpcreditcard'])) {
			$data['payment_cnp_creditcard'] = $this->request->post['payment_cnp_hidcnpcreditcard'];
		} else {
			$data['payment_cnp_creditcard'] = $this->config->get('payment_cnp_creditcard');
		}
		
		if (isset($this->request->post['payment_cnp_hidcnpamex'])) {
			$data['payment_cnp_hidcnpamex'] = $this->request->post['payment_cnp_hidcnpamex'];
		} else {
			$data['payment_cnp_hidcnpamex'] = $this->config->get('payment_cnp_hidcnpamex');
		}
		if (isset($this->request->post['payment_cnp_hidcnpjcb'])) {
			$data['payment_cnp_hidcnpjcb'] = $this->request->post['payment_cnp_hidcnpjcb'];
		} else {
			$data['payment_cnp_hidcnpjcb'] = $this->config->get('payment_cnp_hidcnpjcb');
		} 
		if (isset($this->request->post['payment_cnp_hidcnpMaster'])) {
			$data['payment_cnp_hidcnpMaster'] = $this->request->post['payment_cnp_hidcnpMaster'];
		} else {
			$data['payment_cnp_hidcnpMaster'] = $this->config->get('payment_cnp_hidcnpMaster');
		}  
		if (isset($this->request->post['payment_cnp_hidcnpVisa'])) {
			$data['payment_cnp_hidcnpVisa'] = $this->request->post['payment_cnp_hidcnpVisa'];
		} else {
			$data['payment_cnp_hidcnpVisa'] = $this->config->get('payment_cnp_hidcnpVisa');
		}  
		if (isset($this->request->post['payment_cnp_hidcnpDiscover'])) {
			$data['payment_cnp_hidcnpDiscover'] = $this->request->post['payment_cnp_hidcnpDiscover'];
		} else {
			$data['payment_cnp_hidcnpDiscover'] = $this->config->get('payment_cnp_hidcnpDiscover');
		} 
		 
		if (isset($this->request->post['payment_cnp_hidcnpeCheck'])) {
			$data['payment_cnp_check'] = $this->request->post['payment_cnp_hidcnpeCheck'];
		} else {
			$data['payment_cnp_check'] = $this->config->get('payment_cnp_check');
		}
 		if (isset($this->request->post['payment_cnp_purchas_order'])) {
			$data['payment_cnp_purchas_order'] = $this->request->post['payment_cnp_purchas_order'];
		} else {
			$data['payment_cnp_purchas_order'] = $this->config->get('payment_cnp_purchas_order');
		}
		if (isset($this->request->post['payment_cnp_Visa'])) {
			$data['payment_cnp_Visa'] = $this->request->post['payment_cnp_Visa'];
		} else {
			$data['payment_cnp_Visa'] = $this->config->get('payment_cnp_Visa');
		}
		 if (isset($this->request->post['payment_cnp_American_Express'])) {
			$data['payment_cnp_American_Express'] = $this->request->post['payment_cnp_American_Express'];
		} else {
			$data['payment_cnp_American_Express'] = $this->config->get('payment_cnp_American_Express');
		}
		  if (isset($this->request->post['payment_cnp_Discover'])) {
			$data['payment_cnp_Discover'] = $this->request->post['payment_cnp_Discover'];
		} else {
			$data['payment_cnp_Discover'] = $this->config->get('payment_cnp_Discover');
		}
		   if (isset($this->request->post['payment_cnp_MasterCard'])) {
			$data['payment_cnp_MasterCard'] = $this->request->post['payment_cnp_MasterCard'];
		} else {
			$data['payment_cnp_MasterCard'] = $this->config->get('payment_cnp_MasterCard');
		}
		   if (isset($this->request->post['payment_cnp_JCB'])) {
			$data['payment_cnp_JCB'] = $this->request->post['payment_cnp_JCB'];
		} else {
			$data['payment_cnp_JCB'] = $this->config->get('payment_cnp_JCB');
		}
		if (isset($this->request->post['payment_cnp_payment_custom_titles'])) {
			$data['payment_cnp_payment_custom_titles'] = $this->request->post['payment_cnp_payment_custom_titles'];
		} else {
			$data['payment_cnp_payment_custom_titles'] = $this->config->get('payment_cnp_payment_custom_titles');
		}
		if (isset($this->request->post['payment_cnp_reference_label'])) {
			$data['payment_cnp_reference_label'] = $this->request->post['payment_cnp_reference_label'];
		} else {
			$data['payment_cnp_reference_label'] = $this->config->get('payment_cnp_reference_label');
		}
		
		if (isset($this->request->post['payment_cnp_payment_method'])) {
			$data['payment_cnp_payment_method'] = $this->request->post['payment_cnp_payment_method'];
		} else {
			$data['payment_cnp_payment_method'] = $this->config->get('payment_cnp_payment_method');
		}
		
		if (isset($this->request->post['payment_cnp_payoptn'])) {
			$data['payment_cnp_payoptn'] = $this->request->post['payment_cnp_payoptn'];
		} else {
			$data['payment_cnp_payoptn'] = $this->config->get('payment_cnp_payoptn');
		}
		 
		if (isset($this->request->post['payment_cnp_isRecurring_oto'])) {
			$data['payment_cnp_isRecurring_oto'] = $this->request->post['payment_cnp_isRecurring_oto'];
		} else {
			$data['payment_cnp_isRecurring_oto'] = $this->config->get('payment_cnp_isRecurring_oto');
		}
		if (isset($this->request->post['payment_cnp_isRecurring_recurring'])) {
			$data['payment_cnp_isRecurring_recurring'] = $this->request->post['payment_cnp_isRecurring_recurring'];
		} else {
			$data['payment_cnp_isRecurring_recurring'] = $this->config->get('payment_cnp_isRecurring_recurring');
		}
		if (isset($this->request->post['payment_cnp_dfltpayoptn'])) {
			$data['payment_cnp_dfltpayoptn'] = $this->request->post['payment_cnp_dfltpayoptn'];
		} else {
			$data['payment_cnp_dfltpayoptn'] = $this->config->get('payment_cnp_dfltpayoptn');
		}
		if (isset($this->request->post['payment_cnp_rectype'])) {
			$data['payment_cnp_rectype'] = $this->request->post['payment_cnp_rectype'];
		} else {
			$data['payment_cnp_rectype'] = $this->config->get('payment_cnp_rectype');
		}
		if (isset($this->request->post['payment_cnp_Installment'])) {
			$data['payment_cnp_Installment'] = $this->request->post['payment_cnp_Installment'];
		} else {
			$data['payment_cnp_Installment'] = $this->config->get('payment_cnp_Installment');
		}
		if (isset($this->request->post['payment_cnp_Subscription'])) {
			$data['payment_cnp_Subscription'] = $this->request->post['payment_cnp_Subscription'];
		} else {
			$data['payment_cnp_Subscription'] = $this->config->get('payment_cnp_Subscription');
		}
		 if (isset($this->request->post['payment_cnp_dfltrectypoptn'])) {
			$data['payment_cnp_dfltrectypoptn'] = $this->request->post['payment_cnp_dfltrectypoptn'];
		} else {
			$data['payment_cnp_dfltrectypoptn'] = $this->config->get('payment_cnp_dfltrectypoptn');
		}
		 if (isset($this->request->post['payment_cnp_periodicity'])) {
			$data['payment_cnp_periodicity'] = $this->request->post['payment_cnp_periodicity'];
		} else {
			$data['payment_cnp_periodicity'] = $this->config->get('payment_cnp_periodicity');
		}
		 
		 if (isset($this->request->post['payment_cnp_Week'])) {
			$data['payment_cnp_Week'] = $this->request->post['payment_cnp_Week'];
		} else {
			$data['payment_cnp_Week'] = $this->config->get('payment_cnp_Week');
		}
		
		if (isset($this->request->post['payment_cnp_2_Weeks'])) {
			$data['payment_cnp_2_Weeks'] = $this->request->post['payment_cnp_2_Weeks'];
		} else {
			$data['payment_cnp_2_Weeks'] = $this->config->get('payment_cnp_2_Weeks');
		}
	
		if (isset($this->request->post['payment_cnp_Month'])) {
			$data['payment_cnp_Month'] = $this->request->post['payment_cnp_Month'];
		} else {
			$data['payment_cnp_Month'] = $this->config->get('payment_cnp_Month');
		}

		if (isset($this->request->post['payment_cnp_2_Months'])) {
			$data['payment_cnp_2_Months'] = $this->request->post['payment_cnp_2_Months'];
		} else {
			$data['payment_cnp_2_Months'] = $this->config->get('payment_cnp_2_Months');
		}
		
		if (isset($this->request->post['payment_cnp_Quarter'])) {
			$data['payment_cnp_Quarter'] = $this->request->post['payment_cnp_Quarter'];
		} else {
			$data['payment_cnp_Quarter'] = $this->config->get('payment_cnp_Quarter');
		}
		
		if (isset($this->request->post['payment_cnp_6_Months'])) {
			$data['payment_cnp_6_Months'] = $this->request->post['payment_cnp_6_Months'];
		} else {
			$data['payment_cnp_6_Months'] = $this->config->get('payment_cnp_6_Months');
		}

		if (isset($this->request->post['payment_cnp_Year'])) {
			$data['payment_cnp_Year'] = $this->request->post['payment_cnp_Year'];
		} else {
			$data['payment_cnp_Year'] = $this->config->get('payment_cnp_Year');
		}
		 if (isset($this->request->post['payment_cnp_noofpayments'])) {
			$data['payment_cnp_noofpayments'] = $this->request->post['payment_cnp_noofpayments'];
		} else {
			$data['payment_cnp_noofpayments'] = $this->config->get('payment_cnp_noofpayments');
		}
		 if (isset($this->request->post['payment_cnp_indefinite'])) {
			$data['payment_cnp_indefinite'] = $this->request->post['payment_cnp_indefinite'];
		} else {
			$data['payment_cnp_indefinite'] = $this->config->get('payment_cnp_indefinite');
		}
		 if (isset($this->request->post['payment_cnp_dfltnoofpaymentslbl'])) {
			$data['payment_cnp_dfltnoofpaymentslbl'] = $this->request->post['payment_cnp_dfltnoofpaymentslbl'];
		} else {
			$data['payment_cnp_dfltnoofpaymentslbl'] = $this->config->get('payment_cnp_dfltnoofpaymentslbl');
		}
		 if (isset($this->request->post['payment_cnp_dfltnoofpaymnts'])) {
			$data['payment_cnp_dfltnoofpaymnts'] = $this->request->post['payment_cnp_dfltnoofpaymnts'];
		} else {
			$data['payment_cnp_dfltnoofpaymnts'] = $this->config->get('payment_cnp_dfltnoofpaymnts');
		}
		 if (isset($this->request->post['payment_cnp_maxnoofinstallments'])) {
			$data['payment_cnp_maxnoofinstallments'] = $this->request->post['payment_cnp_maxnoofinstallments'];
		} else {
			$data['payment_cnp_maxnoofinstallments'] = $this->config->get('payment_cnp_maxnoofinstallments');
		}
	
		if (isset($this->request->post['payment_cnp_maxrecurrings_Subscription'])) {
			$data['payment_cnp_maxrecurrings_Subscription'] = $this->request->post['payment_cnp_maxrecurrings_Subscription'];
		} else {
			$data['payment_cnp_maxrecurrings_Subscription'] = $this->config->get('payment_cnp_maxrecurrings_Subscription');
		}
		 $cnpacccnt = $this->model_extension_payment_cnp->getCnPAccountNumrows();
		 if ($cnpacccnt > 0) {
			$data['show_settings'] = true;

		} else {
			$data['show_settings'] = false;
		 }
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		 if($cnpacccnt > 0) {
			 $this->response->setOutput($this->load->view('extension/payment/cnpsettings', $data));
		 }
		 else{
			$this->response->setOutput($this->load->view('extension/payment/cnp', $data)); 
		 }
		
		
    }
		public function install() {
		$this->load->model('extension/payment/cnp');
		$this->model_extension_payment_cnp->install();
		}
		public function uninstall() {
			$this->load->model('extension/payment/cnp');
			$this->model_extension_payment_cnp->uninstall();
		}
	public function ajaxGetCnPCode()
	{
		$curl = curl_init();
		$cnpemailaddress = $_REQUEST['cnpemail_id'];
		curl_setopt_array($curl, array(
  		CURLOPT_URL => "https://api.cloud.clickandpledge.com/users/requestcode",
  		CURLOPT_RETURNTRANSFER => true,
  	    CURLOPT_ENCODING => "",
  		CURLOPT_MAXREDIRS => 10,
  	    CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache",
        "content-type: application/x-www-form-urlencoded",
        "email: ".$cnpemailaddress
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
		
	}
	public function ajaxGetCnPToken()
	{
		$cnpemailid = $_REQUEST['cnpemail_id'];
		$cnpcode = $_REQUEST['cnpcode_val'];
		$this->load->model('extension/payment/cnp');	
		$rtncnpdata = $this->model_extension_payment_cnp->getCnPsettingsinfo($cnpemailid,$cnpcode);
		$curl = curl_init();
		  curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://aaas.cloud.clickandpledge.com/idserver/connect/token",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => $rtncnpdata,
		  CURLOPT_HTTPHEADER => array(
			"cache-control: no-cache",
			"content-type: application/x-www-form-urlencoded"

		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
			$cnptokendata = json_decode($response);
			
			if(!isset($cnptokendata->error)){
			$cnptoken = $cnptokendata->access_token;
			$cnprtoken = $cnptokendata->refresh_token;
			$rtnacntstdcnpdata = $this->model_extension_payment_cnp->CnPtokenDeleteList();
			$rtncnpdata = $this->model_extension_payment_cnp->CnPTokeninfo($cnpemailid,$cnpcode,$cnptoken,$cnprtoken);
			if($rtncnpdata == true)
			{
				$curl = curl_init();

			  curl_setopt_array($curl, array(
  			  CURLOPT_URL => "https://api.cloud.clickandpledge.com/users/accountlist",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			  CURLOPT_HTTPHEADER => array(
				"accept: application/json",
				"authorization: Bearer ".$cnptoken,
				"content-type: application/json"),
			  	));

				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				 
					$cnpAccountsdata = json_decode($response);
					$rtnacntsadcnpdata = $this->model_extension_payment_cnp->CnPAccountDeleteList();
					foreach($cnpAccountsdata as $cnpkey =>$cnpvalue)
					{
					 $cnporgid = $cnpvalue->OrganizationId;
					 $cnporgname = addslashes($cnpvalue->OrganizationName);
					 $cnpaccountid = $cnpvalue->AccountGUID;
					 $cnpufname = addslashes($cnpvalue->UserFirstName);
					 $cnplname = addslashes($cnpvalue->UserLastName);
				     $cnpuid = $cnpvalue->UserId;
						   
							$rtncnpdata = $this->model_extension_payment_cnp->CnPAccountList($cnporgid,$cnporgname,$cnpaccountid,$cnpufname,$cnplname,$cnpuid);
					}
					
				   echo "success";
				}
			}
			}else{
				echo "error";
			}
			
	}
	}
	public function deleteCnPUsers()
	{
		  $this->load->model('extension/payment/cnp');	
		  $cnpdlid = $_REQUEST['cnpemail_id'];
		  $rtnacntsadcnpdata = $this->model_extension_payment_cnp->CnPAccountDeleteList($cnpdlid);
		  $rtnacntstdcnpdata = $this->model_extension_payment_cnp->CnPtokenDeleteList($cnpdlid);
		   $this->redirect($this->url->link('extension/payment/cnp', '', 'SSL'));
	}
	
	public function getCnPUserEmailAccountList()
	{   $this->load->model('extension/payment/cnp');	
		$rtnacntscnpdata = $this->model_extension_payment_cnp->getMCnPUserEmailAccountList($_REQUEST['cnpacid']);
	    echo $rtnacntscnpdata;
	}
	public function getCnPAccountList()
	{
		
		$this->load->model('extension/payment/cnp');	
		
		$rtnrefreshtokencnpdata = $this->model_extension_payment_cnp->getCnPrefreshtoken();
		
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://aaas.cloud.clickandpledge.com/IdServer/connect/token",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => $rtnrefreshtokencnpdata,
		CURLOPT_HTTPHEADER => array(
			"cache-control: no-cache",
			"content-type: application/x-www-form-urlencoded"

		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
			$cnptokendata = json_decode($response);
			$cnptoken = $cnptokendata->access_token;
			$cnprtokentyp = $cnptokendata->token_type;
			if($cnptoken != "")
			{
				$curl = curl_init();

			  curl_setopt_array($curl, array(
  			  CURLOPT_URL => "https://api.cloud.clickandpledge.com/users/accountlist",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			  CURLOPT_HTTPHEADER => array(
				"accept: application/json",
				"authorization: ".$cnprtokentyp." ".$cnptoken,
				"content-type: application/json"),
			  	));

				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				  
					$cnpAccountsdata = json_decode($response); $camrtrnval = "";
					$rtncnpdata = $this->model_extension_payment_cnp->CnPAccountDeleteList();
					
						$confaccno = $this->config->get('payment_cnp_login');
					foreach($cnpAccountsdata as $cnpkey =>$cnpvalue)
					{$selectacnt ="";
					 $cnporgid = $cnpvalue->OrganizationId;
					 $cnporgname = addslashes($cnpvalue->OrganizationName);
					 $cnpaccountid = $cnpvalue->AccountGUID;
					 $cnpufname = addslashes($cnpvalue->UserFirstName);
					 $cnplname = addslashes($cnpvalue->UserLastName);
				     $cnpuid = $cnpvalue->UserId;
						
							$rtncnpdata = $this->model_extension_payment_cnp->CnPAccountList($cnporgid,$cnporgname,$cnpaccountid,$cnpufname,$cnplname,$cnpuid);
	
						if($confaccno == $cnporgid){$selectacnt ="selected='selected'";}
		 $camrtrnval .= "<option value='".$cnporgid."'". $selectacnt .">".$cnpvalue->OrganizationName." --- ".$cnporgid." --- ".$cnpaccountid."</option>";
		

	 }
					echo $camrtrnval;
					}
					
				   
				}
			}
			
	}

protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/cnp')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
	
		if (!$this->request->post['payment_cnp_login'] ) {
			$this->error['login'] = $this->language->get('error_login');
		}
/*if(!$this->request->post['payment_cnp_creditcard'] && !$this->request->post['payment_cnp_check'] && !$this->request->post['payment_cnp_purchas_order'])
{
	$this->error['paymentmethods'] = $this->language->get('error_paymentmethods');
}*/
		/*if (!$this->request->post['cnp_key'] && !$this->request->post['cnp_key_euro'] && !$this->request->post['cnp_key_pound'] && !$this->request->post['cnp_cad_key'] && !$this->request->post['cnp_hkd_key']) {
			$this->error['key'] = $this->language->get('error_key');
		}*/
		
		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}	
	}
}