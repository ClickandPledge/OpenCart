function check_is_recurring(res,name_file)
{
if(res == true)
{
var xmlhttp;
document.getElementById("myDiv").innerHTML= "<img src='../modules/clickandpledge/loading.gif' width='16px' height='16px'>";
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET",name_file+"?action=recurring",true);
xmlhttp.send();
}else{
document.getElementById("myDiv").innerHTML= "";
}
}
function block_recurring(res)
{
	if(res == true)
	document.getElementById("myDiv").style.display="block";
	else
	document.getElementById("myDiv").style.display="none";
}
function block_custom(res)
{
	if(res == true)
	document.getElementById("cnpcustomDiv").style.display="block";
	else
	document.getElementById("cnpcustomDiv").style.display="none";
}
function block_subscription(res)
{
	if(res == true)
	document.getElementById("myDiv1").style.display="block";
	else
	document.getElementById("myDiv1").style.display="none";
}
function block_creditcard(res)
{
	if(res == true)
	{
	document.getElementById("myDiv3").style.display="block";
jQuery('#tblacceptedcards .tracceptedcards').show();
	}
	else
	{
		jQuery('#tblacceptedcards .tracceptedcards').hide();	
	
	if(document.getElementById("payment_cnp_check").checked == false)
	document.getElementById("myDiv3").style.display="none";
	}
}
jQuery("#payment_cnp_Subscription").click(function(){
	if(jQuery('#payment_cnp_Subscription').is(':checked') == true)
	{
		jQuery("#indefinite_div").show();jQuery("#indefinite_openfield_div").show();
		jQuery("#openfild_div").show();jQuery("#fixdnumber_div").show();
	}
	else if(jQuery('#payment_cnp_Subscription').is(':checked') == false)
	{
		jQuery("#indefinite_div").hide();
		jQuery("#indefinite_openfield_div").hide();
	}
});
function defaultpayment() { 
		var paymethods = [];
		var paymethods_titles = [];
		var str = '';
		var defaultval = jQuery('#payment_cnp_DefaultpaymentMethod').val();
		if(jQuery('#payment_cnp_hidcnpcreditcard').val() == "CreditCard") {
				paymethods.push('CreditCard');
				paymethods_titles.push('Credit Card');
		}
		if(jQuery('#payment_cnp_hidcnpeCheck').val() == "eCheck") {
				paymethods.push('eCheck');
				paymethods_titles.push('eCheck');
		}
		if(jQuery('#payment_cnp_purchas_order').is(':checked')) {
		   block_custom(document.clickandpledgesettings.payment_cnp_purchas_order.checked);
		   var titles = jQuery('#payment_cnp_payment_custom_titles').val();
		   var titlesarr = titles.split(";");
		   for(var j=0;j < titlesarr.length; j++)
		   {
			  if(titlesarr[j] !=""){
				  paymethods.push(titlesarr[j]);
				  paymethods_titles.push(titlesarr[j]);
				}
		   }
					} 
					
			if(paymethods.length > 0) {
				for(var i = 0; i < paymethods.length; i++) {
					if(paymethods[i] == defaultval) {
						str += '<option value="'+paymethods[i]+'" selected>'+paymethods_titles[i]+'</option>';
						} else {
						str += '<option value="'+paymethods[i]+'">'+paymethods_titles[i]+'</option>';
				    	}
					}
					} else {
					 str = '<option selected="selected" value="">Please select</option>';
					}
					jQuery('#payment_cnp_payment_method').html(str);
				}
function block_echek(res)
{
	defaultpayment();
	if(jQuery('#payment_cnp_hidcnpcreditcard').val() == "CreditCard" ||jQuery('#payment_cnp_hidcnpeCheck').val() == "eCheck"){
	document.getElementById("myDiv3").style.display="block";}
	else{
	if(jQuery('#payment_cnp_hidcnpcreditcard').val() == "" || jQuery('#payment_cnp_hidcnpeCheck').val() == "") 	{
	   document.getElementById("myDiv3").style.display="none";}
       }
	
}

jQuery('.rectyp').click(function()
				{
				  if(jQuery('#payment_cnp_isRecurring_oto').is(':checked') && jQuery('#payment_cnp_isRecurring_recurring').is(':checked'))
					{
					    jQuery("tr.trdfltpymntoptn").show();
					}
					else
					{
					     jQuery("tr.trdfltpymntoptn").hide();
					}
				
				});
				jQuery('.clsrectype').click(function()
				{
				  if(jQuery('#payment_cnp_Installment').is(':checked') && jQuery('#payment_cnp_Subscription').is(':checked'))
					{
					    jQuery("tr.trdfltrecoptn").show();
					}
					else
					{
					     jQuery("tr.trdfltrecoptn").hide();
					}
				
				});
				
				jQuery(".clsnoofpaymnts").change(function(){
																			
					var noofpay = jQuery(this).val();
					if(noofpay == 1)
					{
						jQuery("#payment_cnp_dfltnoofpaymnts").val('');
						jQuery("#payment_cnp_maxrecurrings_Subscription").val('');
						jQuery("tr.dfltnoofpaymnts").hide();jQuery("tr.maxnoofinstlmnts").hide();
						jQuery('#payment_cnp_maxrecurrings_Subscription').attr('readonly', false);
					}
					if(noofpay == "openfield")
					{
					    jQuery("#payment_cnp_dfltnoofpaymnts").val('');
						jQuery("#payment_cnp_maxrecurrings_Subscription").val('');
						jQuery("tr.dfltnoofpaymnts").show();jQuery("tr.maxnoofinstlmnts").show();
						jQuery('#payment_cnp_maxrecurrings_Subscription').attr('readonly', false);
				   }
					if(noofpay == "indefinite_openfield")
					{
					    jQuery("#payment_cnp_dfltnoofpaymnts").val('');
						jQuery("#payment_cnp_maxrecurrings_Subscription").val('');
						jQuery("tr.dfltnoofpaymnts").show();jQuery("tr.maxnoofinstlmnts").show();
						jQuery("#payment_cnp_dfltnoofpaymnts").val('999');
						jQuery("#payment_cnp_maxrecurrings_Subscription").val('999');
						jQuery('#payment_cnp_maxrecurrings_Subscription').attr('readonly', true);
					}
					if(noofpay == "fixednumber")
					{
					    jQuery("#payment_cnp_dfltnoofpaymnts").val('');
						jQuery("#payment_cnp_maxrecurrings_Subscription").val('');
						jQuery("tr.dfltnoofpaymnts").show();jQuery("tr.maxnoofinstlmnts").hide();
						jQuery('#payment_cnp_maxrecurrings_Subscription').attr('readonly', false);
					}
					
				});
				jQuery("#payment_cnp_Subscription").click(function(){
				if(jQuery('#payment_cnp_Subscription').is(':checked') == true)
				{
				
				 jQuery("#indefinite_div").show();jQuery("#indefinite_openfield_div").show();jQuery("#openfild_div").show();jQuery("#fixdnumber_div").show();
				 
				}
				else if(jQuery('#payment_cnp_Subscription').is(':checked') == false)
				{
				
				  jQuery("#indefinite_div").hide();jQuery("#indefinite_openfield_div").hide();
				  jQuery('input[name="payment_cnp_indefinite"]').prop('checked', false);
				}
				
				});


jQuery('#payment_payment_custom_titles').change(function() {
	defaultpayment();
});
jQuery('#payment_cnp_creditcard').click(function() {
	defaultpayment();
if(!jQuery('#payment_cnp_creditcard').is(':checked') && !jQuery('#payment_cnp_check').is(':checked')) {
		document.getElementById("myDiv3").style.display="none";
} else {
if(jQuery('#payment_cnp_creditcard').is(':checked') || jQuery('#payment_cnp_check').is(':checked')) {
		document.getElementById("myDiv3").style.display="block";
	}
}	
});
jQuery('#payment_cnp_purchas_order').click(function() {
	defaultpayment();
});
jQuery('#payment_cnp_regemailid').click(function() {
	alert(jQuery('#payment_cnp_regemailid').val());
});


jQuery('#payment_cnp_login').change(function() {
	
		 	 $.ajax({
				  type: "POST", 
				  url: "index.php?route=extension/payment/cnp/getCnPUserEmailAccountList&cnpacid="+jQuery('#payment_cnp_login').val()+"&user_token="+ getURLVar('user_token'),
				  cache: false,
				  beforeSend: function() {
					
					$("#payment_cnp_connectcampaign_URLalias").html("<option>Loading............</option>");
					},
					complete: function() {
					
					},	
				  success: function(htmlText) {
				  if(htmlText !== "")
				  {
					
					var res = htmlText.split("||");
					$("#payment_cnp_connectcampaign_URLalias").html(res[0]);  
					$("#cnpacceptedcards").html(res[1]);  
					  if($("#payment_cnp_purchas_order").prop('checked') == true){
						  $("#cnpcustomDiv").show();
						  defaultpayment();
					  }
					  else{						  $("#cnpcustomDiv").hide();defaultpayment();}
				  //$(".cnpcode").show();
				  }
				  else
				  {
				  $(".cnperror").show();
				  }
					
				  },
				  error: function(xhr, ajaxOptions, thrownError) {
					alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				  }
				});
	 return false;
 });
 $('#rfrshtokens').on('click', function() 
		 {  
		 	 $.ajax({
				  type: "POST", 
				  url: "index.php?route=extension/payment/cnp/getCnPAccountList&user_token="+ getURLVar('user_token'),
				  cache: false,
				  beforeSend: function() {
					$('.cnp_loader').show();
					$("#cnp_login").html("<option>Loading............</option>");
					},
					complete: function() {
						$('.cnp_loader').hide();
						
					//	$("#cnp_btncode").prop('value', 'Login');
					},	
				  success: function(htmlText) {
				  if(htmlText !== "")
				  {
					
					$("#payment_cnp_login").html(htmlText);  
				  //$(".cnpcode").show();
				  }
				  else
				  {
				  $(".cnperror").show();
				  }
					
				  },
				  error: function(xhr, ajaxOptions, thrownError) {
					alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				  }
				});
	 return false;
 });
function check_idefinite(mess)
{
if(mess == "Subscription")
document.getElementById("indefinite_id").innerHTML= '<div style="margin-bottom:10px;"><input type="checkbox" name="indefinite_times" value="999" onclick="is_validating(this.checked)" id="indefinite_times"> <label class="option" for="indefinite_times"><span></span>Indefinite Recurring</lable></div>';
else
document.getElementById("indefinite_id").innerHTML= '';
is_validating(false);
}
function recurring_setup(mess,install,subcri,vv,indefinite)
{
if(mess == 1)
{
var html ='<h4>Recurring Method</h4>';
if(install == 'Installment')
{
	html +='<div style="margin-bottom:10px; margin-top:10px;"><input type="radio" id="installment" name="recurring_method" value="Installment" checked="checked" onclick="check_idefinite(this.value)"><label class="option" for="installment"><span></span> Installment (example: Split $1000 into 10 payments of $100 each)</div>'; 
}
if(subcri == 'Subscription')
{
	if(install == '') var cc= 'checked="checked"';else cc ='';
	html +='<div style="margin-bottom:10px; margin-top:10px;"><input type="radio" id="subscription" name="recurring_method" value="Subscription" onclick="check_idefinite(this.value)" '+cc+'><label class="option" for="subscription"><span></span> Subscription (example: Pay $10 every month for 20 times)</div>'; 
	
	if(indefinite == 999)
	{
	html +='<div id="indefinite_id"></div>';
	}
	if(cc != '')
	{
	setTimeout("check_idefinite('Subscription')", 50);	
	}
	
}
	if(install == 'Installment' || subcri == 'Subscription')
	{	add='';
		html +='<div style="margin-bottom:10px;"><b>every</b> <select name="Periodicity">';
		
		vv= vv.filter(function(e){return e});
		for (var i=0;i<vv.length;i++)
		{
		add += '<option value="'+vv[i]+'">'+vv[i]+'</option>';	
		}
		html +=add+'</select>&nbsp;&nbsp;<span id="times">&nbsp;<b>for</b>&nbsp;<input type="text" name="number_of_times" size="3" maxlength="3">&nbsp;<b>times</b></span><span id="enable" style="display:none;color:green">Until Cancelled </span></div>'; 
		document.getElementById("method_display").innerHTML= html;
	}
	else{
		document.getElementById("method_display").innerHTML= '';
	}
}
if(mess == 0)
{
document.getElementById("method_display").innerHTML= '';	
}
}
function is_validating(mess)
{
if(mess)
{
	document.getElementById("times").style.display = 'none';
	document.getElementById("enable").style.display = 'inline';
}
else
{
	document.getElementById("times").style.display = 'inline';
	document.getElementById("enable").style.display = 'none';
}
}